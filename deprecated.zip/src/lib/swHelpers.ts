/* File contains helper functions to use with service worker related tasks */

import { SupabaseClient, User } from '@supabase/supabase-js';

import React from 'react';

// Function to convert a URL base64 string to a Uint8Array
export function base64ToUint8Array(base64String: string | any[]) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export const requestChromeNotifications = async (setBrowserEnabled: React.Dispatch<React.SetStateAction<boolean>>) => {
  if (typeof window !== 'undefined') {
    if (!('Notification' in window)) {
      // Check if the browser supports notifications
      // alert('This browser does not support desktop notification');
      // Safari only has PWA notifications
      setBrowserEnabled(true);
    } else if (Notification.permission === 'granted') {
      setBrowserEnabled(true);
    } else if (Notification.permission !== 'denied') {
      // We need to ask the user for permission
      const permission = await Notification.requestPermission();
      // If the user accepts, let's create a notification
      if (permission === 'granted') {
        setBrowserEnabled(true);
      }
    }
  }
};

// Function to subscribe the user to push notifications
export const subscribeUserToPush = async (
  registration: ServiceWorkerRegistration | null,
  setSubscription: React.Dispatch<React.SetStateAction<PushSubscription | null>>,
  setIsSubscribed: React.Dispatch<React.SetStateAction<boolean>>,
  setBrowserEnabled: React.Dispatch<React.SetStateAction<boolean>>,
  supabaseClient: SupabaseClient<Database>,
  user: User | null
) => {
  if (!process.env.NEXT_PUBLIC_WEB_PUSH_PUBLIC_KEY || !registration) return;
  await requestChromeNotifications(setBrowserEnabled);
  const sub = await registration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: base64ToUint8Array(process.env.NEXT_PUBLIC_WEB_PUSH_PUBLIC_KEY),
  });
  await supabaseClient.from('push_subscriptions').insert({ user_id: user?.id, subscription: sub as any });
  setSubscription(sub);
  setIsSubscribed(true);
};

// Function to unsubscribe the user from push notifications
export const unsubscribeUserFromPush = async (
  subscription: PushSubscription | null,
  setSubscription: React.Dispatch<React.SetStateAction<PushSubscription | null>>,
  setIsSubscribed: React.Dispatch<React.SetStateAction<boolean>>,
  supabaseClient: SupabaseClient<Database>,
  user: User | null
) => {
  await subscription?.unsubscribe();
  if (!user?.id) return;
  await supabaseClient
    .from('push_subscriptions')
    .delete()
    .eq('subscription', JSON.stringify(subscription) || '');
  setSubscription(null);
  setIsSubscribed(false);
};

// Function to send push notifications to subscribed users
export const sendNotificationButtonOnClick = async (
  event: React.MouseEvent<HTMLButtonElement>,
  subscription: PushSubscription | null
) => {
  event.preventDefault();
  if (subscription == null) {
    console.error('web push not subscribed');
    return;
  }

  await fetch('/api/services/notification', {
    method: 'POST',
    headers: {
      'Content-type': 'application/json',
    },
    body: JSON.stringify({
      subscription,
    }),
  });
};
