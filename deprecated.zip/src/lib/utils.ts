import { add, formatDistanceStrict } from 'date-fns';

export const convertToGeocodeFeature = (data?: Json | null) => {
  if (!data) return null;
  return data as unknown as Mapbox.GeocodeFeature | null;
};

/* You need Latitude and Longitude to calculate the distance between two locations with following formula:
=acos(sin(lat1)*sin(lat2)+cos(lat1)*cos(lat2)*cos(lon2-lon1))*6371 (6371 is Earth radius in km.) */
export const calculateLngLatDistance = (lngLat1: number[], lngLat2: number[]) => {
  // The math module contains a function
  // named toRadians which converts from
  // degrees to radians.
  const lng1 = (lngLat1[0] * Math.PI) / 180;
  const lng2 = (lngLat2[0] * Math.PI) / 180;
  const lat1 = (lngLat1[1] * Math.PI) / 180;
  const lat2 = (lngLat2[1] * Math.PI) / 180;

  // Haversine formula
  let dlng = lng2 - lng1;
  let dlat = lat2 - lat1;
  let a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlng / 2), 2);

  let c = 2 * Math.asin(Math.sqrt(a));

  // Radius of earth in kilometers. Use 3956
  // for miles
  let r = 6371;

  // calculate the result
  return c * r;
};

export function formatDate(timestamp: string): string {
  const date = new Date(timestamp);
  const day = date.getDate();
  const month = date.getMonth() + 1; // Months are 0-indexed
  const year = date.getFullYear();

  return `${day}/${month}/${year}`;
}

export function convertToKilograms(amount: number | null, unit: string | null, quantity: number | null): number {
  if (amount === null) {
    return 0;
  }

  if (unit === 'Kg') {
    return amount;
  } else if (unit === 'g') {
    return amount / 1000; // Convert grams to kg
  } else if (unit === 'quantity' && quantity !== null) {
    return amount * quantity; // extract quantity and individual weight totals
  } else {
    return 0; // Handle other cases
  }
}

export const formatDateDifferenceShort = (timestamp?: string | null, offset8Hours = false) => {
  if (!timestamp) return '';
  const isoDateTime = new Date(timestamp);
  const localeDateTime = add(isoDateTime, { hours: 8 });
  const currentTime = new Date();
  const timestampFormatted = formatDistanceStrict(offset8Hours ? localeDateTime : isoDateTime, currentTime);
  const shortForm = timestampFormatted
    ?.replace(/ /, '')
    ?.replace(/second(s|)/, 's')
    ?.replace(/minute(s|)/, 'm')
    ?.replace(/hour(s|)/, 'h')
    ?.replace(/day(s|)/, 'd')
    ?.replace(/year(s|)/, 'y');
  return shortForm;
};
