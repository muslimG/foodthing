export const categoryOptions: Field.Options = [
  { value: '', label: 'Select a category', disabled: true },
  { value: 'Bakery Goods', label: 'Bakery Goods' },
  { value: 'Ready Meals', label: 'Ready Meals' },
  { value: 'Pantry Goods', label: 'Pantry Goods' },
  { value: 'Dairy Products', label: 'Dairy Products' },
  { value: 'Fresh Produce', label: 'Fresh Produce' },
  { value: 'Meat, Seafood and Alternatives', label: 'Meat, Seafood and Alternatives' },
  { value: 'Beverages', label: 'Beverages' },
  { value: 'Snacks and Confectionary', label: 'Snacks and Confectionary' },
  { value: 'Other', label: 'Other' }
];

export const subcategoryOptions: Record<string, Field.Options> = {
  'Bakery Goods': [
    { value: 'Bread and breadrolls', label: 'Bread and breadrolls (unfilled)' },
    { value: 'Sweet buns/cakes/biscuits', label: 'Sweet buns/cakes/biscuits' },
    { value: 'Pies/sausage rolls', label: 'Pies/sausage rolls' },
    { value: 'Other bakery goods', label: 'Other bakery goods' }
  ],
  'Ready Meals': [
    { value: 'Salads', label: 'Salads' },
    { value: 'Pre-made sandwiches/rolls', label: 'Pre-made sandwiches/rolls with fillings' },
    { value: 'Single serve meals', label: 'Single serve meals' },
    { value: 'Family meals', label: 'Family meals' },
    { value: 'Other ready meals', label: 'Other ready meals' }
  ],
  'Pantry Goods': [
    { value: 'Canned products', label: 'Canned products' },
    { value: 'Oils and condiments', label: 'Oils and condiments' },
    { value: 'Tea and coffee', label: 'Tea and coffee' },
    { value: 'Pasta, rice and grains', label: 'Pasta, rice and grains' },
    { value: 'Other pantry goods', label: 'Other pantry goods' }
  ],
  'Dairy Products': [
    { value: 'Milk', label: 'Milk' },
    { value: 'Milk based beverages', label: 'Milk based beverages' },
    { value: 'Yoghurt', label: 'Yoghurt' },
    { value: 'Cheese', label: 'Cheese' },
    { value: 'Other dairy products', label: 'Other dairy products' }
  ],
  'Fresh Produce': [
    { value: 'Eggs', label: 'Eggs' },
    { value: 'Fruit', label: 'Fruit' },
    { value: 'Nuts', label: 'Nuts' },
    { value: 'Vegetables', label: 'Vegetables' },
    { value: 'Other fresh produce', label: 'Other fresh produce' }
  ],
  'Meat, Seafood and Alternatives': [
    { value: 'Chicken', label: 'Chicken' },
    { value: 'Beef', label: 'Beef' },
    { value: 'Pork', label: 'Pork' },
    { value: 'Fish', label: 'Fish' },
    { value: 'Other seafood', label: 'Other seafood' },
    { value: 'Plant-based meat alternative', label: 'Plant-based meat alternative' },
    { value: 'Other meat products', label: 'Other meat products' }
  ],
  'Beverages': [
    { value: 'Juice', label: 'Juice' },
    { value: 'Sweetened drinks', label: 'Sweetened drinks' },
    { value: 'Water', label: 'Water' },
    { value: 'Other beverages', label: 'Other beverages' }
  ],
  'Snacks and Confectionary': [
    { value: 'Crisps', label: 'Crisps' },
    { value: 'Crackers', label: 'Crackers' },
    { value: 'Sweet biscuits', label: 'Sweet biscuits' },
    { value: 'Chocolate', label: 'Chocolate/ chocolate bars' },
    { value: 'Lollies', label: 'Lollies' },
    { value: 'Other', label: 'Other' }
  ],
  'Other': [
    { value: 'Other', label: 'Other' }
  ]
};

export const weightOptions: Field.Options = [
  { value: '', label: 'Select a unit of measure', disabled: true },
  { value: 'quantity', label: 'quantity' },
  { value: 'Kg', label: 'kg' },
  { value: 'g', label: 'g' },
];