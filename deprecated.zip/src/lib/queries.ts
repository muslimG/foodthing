import { SupabaseClient, User } from '@supabase/supabase-js';

// user_data queries

export const getCurrentUserData = async (supabaseClient: SupabaseClient<Database>, user: User | null) =>
  await supabaseClient
    .from('user_data')
    .select('*')
    .eq('id', user?.id || '')
    .single();

export const getOtherUserData = async (supabaseClient: SupabaseClient<Database>, userId: string) =>
  await supabaseClient.from('user_data').select('*').eq('id', userId).single();

// donations queries

export const getAllDonations = async (supabaseClient: SupabaseClient<Database>, user: User | null) => {
  return await supabaseClient.from('donations').select('*');
};

export const getCollectableDonations = async (supabaseClient: SupabaseClient<Database>, user: User | null) =>
  await supabaseClient
    .from('donations')
    .select('*')
    .gte('end_date', new Date().toISOString().toLocaleString())
    .is('collector_id', null)
    .order('id', { ascending: false });

export const getCollectorPendingDonations = async (supabaseClient: SupabaseClient<Database>, user: User | null) =>
  await supabaseClient
    .from('donations')
    .select('*')
    .eq('collector_id', user?.id || '')
    .is('confirmDate', null)
    .order('id', { ascending: false });

export const getCollectorCompletedDonations = async (supabaseClient: SupabaseClient<Database>, user: User | null) =>
  await supabaseClient
    .from('donations')
    .select('*')
    .eq('collector_id', user?.id || '')
    .not('confirmDate', 'is', null)
    .order('id', { ascending: false });

export const getDonatorPendingDonations = async (supabaseClient: SupabaseClient<Database>, user: User | null) =>
  await supabaseClient
    .from('donations')
    .select('*')
    .eq('user_id', user?.id || '')
    .is('confirmDate', null)
    .order('id', { ascending: false });

export const getDonatorCompletedDonations = async (supabaseClient: SupabaseClient<Database>, user: User | null) =>
  await supabaseClient
    .from('donations')
    .select('*')
    .eq('user_id', user?.id || '')
    .not('confirmDate', 'is', null)
    .order('id', { ascending: false });

export const getDonationById = async (supabaseClient: SupabaseClient<Database>, donationId: string) =>
  await supabaseClient.from('donations').select('*').eq('id', donationId).single();

export const getChatDonations = async (supabaseClient: SupabaseClient<Database>, user: User | null) =>
  await supabaseClient
    .from('donations')
    .select('*')
    .not('user_id', 'is', null)
    .not('collector_id', 'is', null)
    .is('confirmDate', null)
    .or(`user_id.eq.${user?.id}, collector_id.eq.${user?.id}`)
    .order('id', { ascending: false });

// chat queries

export const getChatByDonationId = async (
  supabaseClient: SupabaseClient<Database>,
  donationId: string,
  creatorId?: string,
  collectorId?: string,
  donation_collection_date?: string | null
) =>
  await supabaseClient
    .from('chat_messages')
    .select('*')
    .eq('donation_id', donationId)
    .or(`sender_id.eq.${creatorId},sender_id.eq.${collectorId}`)
    .gte('chat_date', donation_collection_date)
    .order('chat_date', { ascending: true });

export const getLastChatByDonationId = async (
  supabaseClient: SupabaseClient<Database>,
  donationId: string,
  donation_collection_date?: string | null
) =>
  await supabaseClient
    .from('chat_messages')
    .select('*')
    .eq('donation_id', donationId)
    .order('id', { ascending: false })
    .gte('chat_date', donation_collection_date || new Date().toISOString().toLocaleString())
    .limit(1);

export const updateChatUnreadByDonationId = async (
  supabaseClient: SupabaseClient<Database>,
  donationId: string,
  userId: string
) =>
  await supabaseClient
    .from('chat_messages')
    .update({ is_read: true })
    .eq('is_read', false)
    .eq('donation_id', donationId)
    .neq('sender_id', userId);
