import React from 'react';
import ReactModal from 'react-modal';
import styles from './SingleActionModal.module.scss';

interface Props {
  isOpen: boolean;
  title?: string;
  bodyText?: string;
  onConfirm: () => void;
  setIsOpen: (value: React.SetStateAction<boolean>) => void;
}

const SingleActionModal = ({ isOpen, title, bodyText, onConfirm, setIsOpen }: Props) => {
  return (
    <ReactModal isOpen={isOpen} overlayClassName={styles.overlay} className={styles.modal}>
      <div className={styles.content}>
        <h3>{title}</h3>
        <p>{bodyText}</p>
        <div className={styles.actions}>
          <button className={styles.cancel} onClick={() => setIsOpen(false)}>
            Cancel
          </button>
          <button className={styles.confirm} onClick={() => onConfirm()}>
            Confirm
          </button>
        </div>
      </div>
    </ReactModal>
  );
};

export default SingleActionModal;
