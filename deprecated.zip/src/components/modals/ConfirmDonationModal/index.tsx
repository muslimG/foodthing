import * as yup from 'yup';

import { Form, Formik, FormikHelpers } from 'formik';

import NumberField from '@/components/fields/NumberField';
import QuantityIcon from '@/components/icons/svg/tabler-quantity.svg';
import React from 'react';
import ReactModal from 'react-modal';
import TextField from '@/components/fields/TextField';
import WeightIcon from '@/components/icons/svg/tabler-weight.svg';
import styles from './ConfirmDonationModal.module.scss';
import { useRouter } from 'next/router';
import { useSupabaseClient } from '@supabase/auth-helpers-react';

interface Props {
  isOpen: boolean;
  donationId?: string;
  data: Tables.Donations | null;
  setIsOpen: (value: React.SetStateAction<boolean>) => void;
}

interface ConfirmDonation extends FormikHelper.DonationValues {
  comments: null | string;
}

const ConfirmDonationModal = ({ isOpen, data, donationId, setIsOpen }: Props) => {
  const supabaseClient = useSupabaseClient<Database>();
  const router = useRouter(); // get next router for query param

  const handleSubmit = async (values: ConfirmDonation, formikHelpers?: FormikHelpers<ConfirmDonation>) => {
    const submissionValues = {
      amount: values?.amount,
      quantity: data?.unit === 'quantity' ? values?.quantity : null,
      col_confirm: true,
      confirmDate: data?.don_confirm ? new Date().toISOString().toLocaleString() : null,
      comments: values.comments,
    };

    if (!donationId) return;

    const { error: updateError } = await supabaseClient.from('donations').update(submissionValues).eq('id', donationId);

    if (!updateError && data) {
      await supabaseClient.from('notifications').insert({
        user_id: data.user_id, // This is the original donor's ID
        title: 'The collector has confirmed they collected your donation',
        donation_id: data.id,
      });
    }

    router.reload();
  };

  return (
    <ReactModal isOpen={isOpen} overlayClassName={styles.overlay} className={styles.modal}>
      <Formik
        onSubmit={handleSubmit}
        initialValues={ConfirmDonationModal.initialValues(data)}
        validationSchema={confirmationSchema}>
        {() => (
          <Form className={styles.form}>
            <div className={styles.innerContent}>
              <p>
                Confirm the amount that you collected is accurate for reporting. You can leave the value as is if the
                donation was the amount described. You can also leave any additional comments.
              </p>
              {data?.unit === 'quantity' ? (
                <div className={styles.quantityAndAmount}>
                  <div className={styles.field}>
                    <WeightIcon className={styles.svgScale} />
                    <NumberField name="amount" placeholder="Approximate kg per item" unitOverlay="kg" />
                  </div>
                  <div className={styles.field}>
                    <QuantityIcon className={styles.svgScale} />
                    <NumberField name="quantity" placeholder="Enter Quantity" step={1} />
                  </div>
                </div>
              ) : (
                <div className={styles.amountOnly}>
                  <WeightIcon />
                  <NumberField name="amount" placeholder="approximation of food" unitOverlay={data?.unit || ''} />
                </div>
              )}
              <TextField name="comments" placeholder="Comments" />
            </div>
            <div className={styles.actions}>
              <button type="button" className={styles.cancelBtn} onClick={() => setIsOpen(false)}>
                Cancel
              </button>
              <button type="submit" className={styles.submit}>
                Confirm Collection
              </button>
            </div>
          </Form>
        )}
      </Formik>
    </ReactModal>
  );
};

ConfirmDonationModal.initialValues = (initialData: Tables.Donations | null): ConfirmDonation => ({
  title: '',
  description: '',
  amount: initialData?.amount || 0.0,
  unit: initialData?.unit || '',
  endDate: '',
  location: '',
  locationData: null,
  category: '',
  subCategory: '',
  imagePath: '',
  quantity: initialData?.quantity || 0,
  comments: '',
});

let confirmationSchema = yup.object({
  amount: yup
    .number()
    .min(0.1, 'Must be atleast 100 grams')
    .required("Please input the amount you're donating")
    .positive(),
  quantity: yup.number().when('unit', {
    is: 'quantity',
    then: (schema) => schema.min(1),
  }),
});

export default ConfirmDonationModal;
