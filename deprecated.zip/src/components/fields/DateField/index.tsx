import { Field, useField } from 'formik';

import React from 'react';
import cc from 'classcat';
import styles from './index.module.scss';

interface DateFieldProps {
  name: string;
  label?: string;
  className?: string;
}

const DateField = ({ name, label, className }: DateFieldProps) => {
  const [, { error, touched }] = useField({ name });

  return (
    <div className={styles.wrapper}>
      {label && <label className={styles.label}>{label}</label>}

      <Field
        id={name}
        name={name}
        type="datetime-local"
        className={cc([styles.field, className])}
        data-testid={`${name}-field`}
      />
      {touched && error && <div className={styles.error}>{error}</div>}
    </div>
  );
};

export default DateField;
