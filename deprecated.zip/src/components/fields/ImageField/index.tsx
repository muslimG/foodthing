import React, { useState } from 'react';

import Image from '@/components/Image';
import TrashIcon from '@/components/icons/svg/tabler-trash.svg';
import UploadIcon from '@/components/icons/svg/tabler-cloud-up.svg';
import imageCompression from 'browser-image-compression';
import styles from './index.module.scss';
import { useField } from 'formik';
import { useSupabaseClient } from '@supabase/auth-helpers-react';
import { v4 as uuidv4 } from 'uuid';

interface Props {
  name: string;
  label?: string;
  className?: string;
  uploadPath?: string;
  existingImageSrc?: string;
}

const ImageField = ({ name, label, uploadPath = 'donation_images', existingImageSrc = '', className }: Props) => {
  const [imgSrc, setImgSrc] = useState(existingImageSrc);
  const [{}, {}, { setValue }] = useField(name);
  const supabaseClient = useSupabaseClient<Database>();

  const handleDeleteImage = () => {
    setImgSrc('');
    setValue('');
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const imagePath = `${uploadPath}/${uuidv4()}`;
    const file = e.target.files?.[0];

    if (!file) {
      setValue(null);
      return;
    }

    const options = {
      maxSizeMB: 1,
      maxWidthOrHeight: 1920,
      useWebWorker: true,
    };
    try {
      const compressedFile = await imageCompression(file, options);

      const { data, error } = await supabaseClient.storage.from('imageFile').upload(imagePath, compressedFile);

      if (data && !error) {
        setValue(imagePath);
      }

      setImgSrc(URL.createObjectURL(compressedFile));
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className={styles.wrapper}>
      {label && <p className={styles.label}>{label}</p>}

      {/* we have to use the label to style */}
      {!imgSrc && (
        <>
          <label htmlFor={name} className={styles.addImg}>
            <UploadIcon className={styles.icon} />
          </label>
          <input
            id={name}
            name={name}
            type="file"
            accept="image/*"
            className={className}
            onChange={handleImageChange}
            data-testid={`${name}-field`}
          />
        </>
      )}

      {!!imgSrc && (
        <div className={styles.imagePreview}>
          <TrashIcon className={styles.deleteImg} onClick={handleDeleteImage} />
          <Image src={imgSrc} alt="Uploaded Image" />
        </div>
      )}
    </div>
  );
};
export default ImageField;
