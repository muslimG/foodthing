import { Field, useField } from 'formik';

import React from 'react';
import cc from 'classcat';
import styles from './index.module.scss';

interface CheckBoxOption {
  value: string | boolean;
  label?: string;
  elem?: JSX.Element;
}

interface CheckBoxFieldProps {
  name: string;
  label?: string;
  options: CheckBoxOption[];
  className?: string;
}

const CheckBoxField = ({ name, label, options, className }: CheckBoxFieldProps) => {
  const [{}, { touched, error }] = useField(name);

  return (
    <div className={styles.wrapper}>
      {label && <label className={styles.label}>{label}</label>}
      <div className={cc([styles.field, className])}>
        {options.map((option, idx) => (
          <label htmlFor={name} key={`${option.label ?? option.value}-${idx}`} className={styles.clickableSection}>
            <span className={styles.checkmark} />
            <Field type="CheckBox" name={name} value={option.value} className={styles.input} />
            {option?.label && <span className={styles.label}>{option.label}</span>}
            {option?.elem && <span className={styles.label}>{option?.elem}</span>}
          </label>
        ))}
      </div>
      {touched && error && <div className={styles.error}>{error}</div>}
    </div>
  );
};

export default CheckBoxField;
