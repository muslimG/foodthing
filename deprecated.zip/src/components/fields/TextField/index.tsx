import { Field, useField, useFormik, useFormikContext } from 'formik';

import React from 'react';
import cc from 'classcat';
import styles from './index.module.scss';

interface Props {
  name: string;
  label?: string;
  placeholder?: string;
  className?: string;
  type?: 'email' | 'text' | 'password' | 'tel';
  submitOnEnter?: boolean;
  autoComplete?: string;
  disabled?: boolean;
}

const TextField = ({ name, label, placeholder, className, type, submitOnEnter, autoComplete, disabled }: Props) => {
  const { handleSubmit } = useFormikContext();
  const [, { error, touched }] = useField(name);

  return (
    <div className={styles.wrapper}>
      {label && <label className={styles.label}>{label}</label>}
      <Field
        id={name}
        name={name}
        className={cc([styles.field, className])}
        data-testid={`${name}-field`}
        placeholder={placeholder}
        type={type}
        autoComplete={autoComplete}
        disabled={disabled}
        onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
          if (e.key === 'Enter' && submitOnEnter) {
            handleSubmit();
          }
        }}
      />
      {touched && error && <div className={styles.error}>{error}</div>}
    </div>
  );
};

export default TextField;
