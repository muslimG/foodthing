import { Field, useField, useFormikContext } from 'formik';
import React, { useState } from 'react';

import cc from 'classcat';
import mockSuggestions from './mockSuggestion';
import styles from './index.module.scss';

interface Props {
  name?: string;
  dataName?: string;
  label?: string;
  placeholder?: string;
  className?: string;
  mockData?: boolean;
}

const AddressField = ({
  name = 'address',
  dataName,
  label,
  placeholder = 'Enter address',
  className,
  mockData,
}: Props) => {
  const [{ value }, { error, touched }, { setValue }] = useField(name);
  const [{}, { error: dataError }, { setValue: setDataValue }] = useField(dataName ?? `${name}Data`);
  const [suggestions, setSuggestions] = useState<Mapbox.GeocodeFeature[]>(mockData ? mockSuggestions : []);
  const [shouldFetch, setShouldFetch] = useState(true);

  const handleChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value;
    setValue(inputValue);

    // Debounces call to only run every 3 seconds and after 5 characters max
    if (inputValue?.length < 5 || !shouldFetch) {
      return;
    }

    setShouldFetch(false);

    setTimeout(() => {
      setShouldFetch(true);
    }, 1000);

    // DOCs https://docs.mapbox.com/api/search/geocoding/
    try {
      const endpoint = `https://api.mapbox.com/geocoding/v5/mapbox.places/${inputValue}.json?access_token=${process.env.NEXT_PUBLIC_MAPBOX_TOKEN}&autocomplete=true&country=AU&types=address`;
      const response = await fetch(endpoint);
      const results = (await response.json()) as Mapbox.GeocodeResult;
      setSuggestions(results?.features);
    } catch (error) {
      console.log('Error fetching data, ', error);
    }
  };

  return (
    <div className={styles.wrapper}>
      {label && <label className={styles.label}>{label}</label>}
      <input
        id={name}
        name={name}
        className={cc([styles.field, className])}
        data-testid={`${name}-field`}
        placeholder={placeholder}
        type="text"
        onChange={handleChange}
        value={value}
      />
      {((touched && error) || (touched && dataError)) && <div className={styles.error}>{error ?? dataError}</div>}
      {!!suggestions?.length && (
        <div className={styles.suggestions}>
          {suggestions?.map((suggestion) => (
            <p
              key={suggestion.id}
              onClick={() => {
                setValue(suggestion.place_name);
                setDataValue(suggestion);
                setSuggestions([]);
              }}
              className={styles.suggestion}>
              {suggestion?.place_name}
            </p>
          ))}
        </div>
      )}
    </div>
  );
};

export default AddressField;
