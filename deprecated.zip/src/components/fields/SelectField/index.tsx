import { Field, useField } from 'formik';
import React, { SelectHTMLAttributes, useState } from 'react';

import cc from 'classcat';
import styles from './index.module.scss';

interface SelectFieldProps {
  name: string;
  label?: string;
  options: Field.Options;
  className?: string;
}

const SelectField = ({ name, label, options, className }: SelectFieldProps) => {
  const [, { error, touched }] = useField(name); // Use the useField hook to get field and meta props
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  const closeSelect = (e: React.MouseEvent<HTMLOptionElement>) => {
    setIsFocused(false);
    e.currentTarget?.parentElement?.blur();
  };

  const selectSize = isFocused ? (options?.length < 4 ? options?.length : 4) : 1;

  return (
    <div className={styles.wrapper}>
      {label && <label className={styles.label}>{label}</label>}

      <div className={styles.whiteBg}>
        <Field
          as="select"
          id={name}
          name={name}
          className={cc([styles.field, className])}
          data-testid={`${name}-field`}
          onFocus={handleFocus}
          onBlur={handleBlur}
          size={selectSize}>
          {options.map((option) => (
            <option
              key={option.value}
              value={option.value}
              disabled={option?.disabled}
              className={styles.subCat}
              onClick={closeSelect}>
              {option.label}
            </option>
          ))}
        </Field>
      </div>
      {touched && error && <div className={styles.error}>{error}</div>}
    </div>
  );
};

export default SelectField;
