import { Field, useField } from 'formik';

import React from 'react';
import cc from 'classcat';
import styles from './index.module.scss';

interface NumberFieldProps {
  name: string;
  label?: string;
  step?: number;
  placeholder?: string;
  className?: string;
  unitOverlay?: string;
}

const NumberField = ({ name, label, placeholder, step, className, unitOverlay }: NumberFieldProps) => {
  const [field, { touched, error }] = useField(name); // Use the useField hook to get field and meta props

  return (
    <div className={styles.wrapper}>
      {label && <label className={styles.label}>{label}</label>}
      <div className={styles.fieldWrapper}>
        <Field
          id={name}
          name={name}
          type="number"
          className={cc([styles.field, className])}
          data-testid={`${name}-field`}
          placeholder={placeholder}
          step={step}
        />
        <div className={styles.unitOverlay}>{unitOverlay}</div>
      </div>
      {touched && error && <div className={styles.error}>{error}</div>}
    </div>
  );
};

export default NumberField;
