import { Field, useField, useFormik, useFormikContext } from 'formik';

import React from 'react';
import cc from 'classcat';
import styles from './index.module.scss';

interface Props {
  name: string;
  className?: string;
  type?: 'email' | 'text' | 'password' | 'tel';
  submitOnEnter?: boolean;
  autoComplete?: string;
  selections: string[];
}

const LightSwitchField = ({ name, selections, className, type, submitOnEnter, autoComplete }: Props) => {
  const { handleSubmit } = useFormikContext();
  const [{ value }, { error, touched }, { setValue }] = useField(name);

  return (
    <div className={styles.wrapper}>
      <div className={styles.switcher} style={{ left: selections[0] === value ? 0 : '50%' }} />
      {selections?.map((selection) => (
        <button
          type="button"
          key={selection}
          className={cc({ [styles.selection]: true, [styles.active]: selection === value })}
          onClick={() => setValue(selection, true)}>
          {selection}
        </button>
      ))}

      <Field id={name} name={name} data-testid={`${name}-field`} type="hidden" autoComplete={autoComplete} />
      {touched && error && <div className={styles.error}>{error}</div>}
    </div>
  );
};

export default LightSwitchField;
