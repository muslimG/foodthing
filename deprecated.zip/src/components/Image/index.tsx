import React from 'react';

interface Props {
  src: string;
  alt: string;
  className?: string;
  loading?: string;
  onClick?: () => void;
}

// Wrapper function to ignore next lint errors if you want to use normal image
function Image({ src, alt, className, loading, onClick }: Props) {
  return (
    /*  eslint-disable @next/next/no-img-element */
    <img src={src} alt={alt} className={className} loading={'lazy' ?? loading} onClick={onClick} />
  );
}

export default Image;
