import BaguetteIcon from '@/components/icons/svg/tabler-baguette.svg';
import CandyIcon from '@/components/icons/svg/tabler-candy.svg';
import CheeseIcon from '@/components/icons/svg/tabler-cheese.svg';
import CookieIcon from '@/components/icons/svg/tabler-cookie.svg';
import CupIcon from '@/components/icons/svg/tabler-cup.svg';
import LemonIcon from '@/components/icons/svg/tabler-lemon.svg';
import MeatIcon from '@/components/icons/svg/tabler-meat.svg';
import PaperBagIcon from '@/components/icons/svg/tabler-paper-bag.svg';
import React from 'react';
import SoupIcon from '@/components/icons/svg/tabler-soup.svg';

interface Props {
  category: string | null;
  className?: string;
}

const DonationDynamicIcon = ({ category, className }: Props) => {
  switch (category) {
    case 'Bakery Goods':
      return <BaguetteIcon className={className} />;
    case 'Ready Meals':
      return <SoupIcon className={className} />;
    case 'Pantry Goods':
      return <CookieIcon className={className} />;
    case 'Dairy Products':
      return <CheeseIcon className={className} />;
    case 'Fresh Produce':
      return <LemonIcon className={className} />;
    case 'Meat, Seafood and Alternatives':
      return <MeatIcon className={className} />;
    case 'Beverages':
      return <CupIcon className={className} />;
    case 'Snacks and Confectionary':
      return <CandyIcon className={className} />;

    case 'Other':
    default:
      return <PaperBagIcon className={className} />;
  }
};

export default DonationDynamicIcon;
