import { Form, Formik, FormikHelpers } from 'formik';
import React, { useState } from 'react';
import { Session, User, useSupabaseClient } from '@supabase/auth-helpers-react';
import { object, ref, string } from 'yup';

import { ScaleLoader } from 'react-spinners';
import TextField from '@/components/fields/TextField';
import styles from './ResetPasswordForm.module.scss';
import { useEffectOnce } from 'react-use';

interface Props {
  code: string;
}

const ResetPasswordForm = ({ code }: Props) => {
  const supabaseClient = useSupabaseClient<Database>();
  const [msg, setMsg] = useState('');
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);

  useEffectOnce(() => {
    async function getUserFromCode() {
      try {
        const {
          data: { user: userRes, session: sessionRes },
        } = await supabaseClient.auth.exchangeCodeForSession(code);
        setUser(userRes);
        setSession(sessionRes);
      } catch (e) {
        // dont worry, be happy
      }
    }

    if (code) getUserFromCode();
  });

  const handleSubmit = async (
    values: FormikHelper.ResetPassword,
    formikHelpers: FormikHelpers<FormikHelper.ResetPassword>
  ) => {
    const { setSubmitting } = formikHelpers;
    const { password } = values;
    setSubmitting(true);
    try {
      const { data, error } = await supabaseClient.auth.updateUser({ password });

      if (error) {
        error?.message ? setMsg(error?.message) : setMsg('An error occured');
      } else {
        setMsg('Your password has been successfully reset and should be able to login');
      }
    } catch (e) {}
    setSubmitting(false);
  };

  return (
    <Formik onSubmit={handleSubmit} initialValues={ResetPasswordForm.initialValues}>
      {({ submitForm, isSubmitting }) => (
        <Form className={styles.form}>
          {!msg &&
            (!isSubmitting ? (
              <>
                <TextField label="Password" name="password" placeholder="Enter password" type="password" />
                <TextField
                  label="Confirm Password"
                  name="confirmPassword"
                  placeholder="confirm Password"
                  type="password"
                />
                <button type="submit">Reset Password</button>
              </>
            ) : (
              <ScaleLoader
                color="#FFFFFF"
                cssOverride={{ margin: 'auto auto' }}
                aria-label="Loading Spinner"
                data-testid="loader"
              />
            ))}

          {msg && <h2 className={styles.msg}>{msg}</h2>}
        </Form>
      )}
    </Formik>
  );
};

ResetPasswordForm.initialValues = {
  password: '',
  confirmPassword: '',
} as FormikHelper.ResetPassword;

ResetPasswordForm.validationSchema = object({
  password: string().required('Please enter a password'),
  confirmPassword: string()
    .oneOf([ref('password')], 'Passwords must match')
    .required('Please confirm password'),
});

export default ResetPasswordForm;
