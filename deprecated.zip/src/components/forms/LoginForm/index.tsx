import { Form, Formik, FormikHelpers } from 'formik';
import React, { useState } from 'react';

import { ScaleLoader } from 'react-spinners';
import TextField from '@/components/fields/TextField';
import styles from './LoginForm.module.scss';
import { useRouter } from 'next/router';
import { useSupabaseClient } from '@supabase/auth-helpers-react';

interface Props {}

const LoginForm = ({}) => {
  const supabaseClient = useSupabaseClient<Database>();
  const router = useRouter();
  const [msg, setMsg] = useState('');

  const handleLogin = async (values: FormikHelper.LoginValues, helpers: FormikHelpers<FormikHelper.LoginValues>) => {
    const { email, password } = values;
    const { setSubmitting } = helpers;
    setMsg('');

    setSubmitting(true);
    try {
      const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });

      error?.message && setMsg(error?.message);

      if (data?.user && data?.session) {
        router.push('/home');
      }
    } catch (e: any) {
      // remove before final product

      const errObj = await e.json();
      console.log(errObj);
    }
    setSubmitting(false);
  };

  return (
    <Formik onSubmit={handleLogin} initialValues={LoginForm.initialValues}>
      {({ isSubmitting }) => (
        <Form className={styles.form}>
          {msg && !isSubmitting && <p className={styles.error}>{msg}</p>}
          <TextField label="Email" name="email" placeholder="Enter email" type="email" />
          <TextField label="Password" name="password" placeholder="Enter password" type="password" />
          {!isSubmitting ? (
            <button type="submit">Login</button>
          ) : (
            <ScaleLoader
              color="#FFFFFF"
              cssOverride={{ margin: 'auto auto' }}
              aria-label="Loading Spinner"
              data-testid="loader"
            />
          )}
        </Form>
      )}
    </Formik>
  );
};

LoginForm.initialValues = {
  email: '',
  password: '',
} as FormikHelper.LoginValues;

export default LoginForm;
