import React, { useEffect, useState } from 'react';

import Link from 'next/link';
import styles from './consentForm.module.scss';

interface Props {
  setTermsOpen: (value: React.SetStateAction<boolean>) => void;
}

//This page is the first that appears to users upon visiting the web application.
const TermsAndConditions = ({ setTermsOpen }: Props) => {
  return (
    <div className={styles.form}>
      <h1>User Agreement Form</h1>
      <br></br>
      <div>Before using the ReFood application, you must agree to the following:</div>
      <h2> For Food Businesses</h2>
      <ul>
        <li>All donated food will be fit for human consumption at the time it was donated.</li>
        <li>
          All donated food must include, where practicable, all handling requirements and time limits for safe
          consumption.
        </li>
      </ul>

      <h2> For Not-for-Profits</h2>
      <ul>
        <li>
          {' '}
          All collectors must have a good understanding of appropriate knowledge of safe food handling practices.
        </li>
        <li>
          {' '}
          The City of Joondalup provides a free online training course for food handlers{' '}
          <Link rel="non-referrer" href="https://imalert.com.au/v6/user-info.php">
            here
          </Link>{' '}
        </li>
      </ul>

      <h2> For Everyone</h2>
      <ul>
        <li>
          ECU is not a participant in the exchange of goods or produce between Donating Organisations or Recipients.
        </li>
        <li>
          ECU has no control on the quantity or quality of the goods or produce exchanged, or the relationship between
          the participants.
        </li>
        <li>ECU does not investigate or guarantee the GST or charitable registration status of any participant.</li>
        <li>
          To the extent permitted by law, ECU does not accept any responsibility or liability for anything which may
          arise from the Donating Organisations’ or Recipients’ participation in this program, or disputes arising
          between participants.
        </li>
      </ul>

      <button className={styles.close} onClick={() => setTermsOpen(false)}>
        Return
      </button>
    </div>
  );
};

export default TermsAndConditions;
