import { Form, Formik, FormikHelpers } from 'formik';
import React, { useState } from 'react';
import { object, string } from 'yup';

import { ScaleLoader } from 'react-spinners';
import TextField from '@/components/fields/TextField';
import styles from './ForgotPasswordForm.module.scss';
import { useSupabaseClient } from '@supabase/auth-helpers-react';

interface Props {}

const redirectTo = process.env.NEXT_PUBLIC_SUPABASE_REDIRECT
  ? `${process.env.NEXT_PUBLIC_SUPABASE_REDIRECT}forgot-password`
  : undefined;

const ForgotPasswordForm = ({}: Props) => {
  const supabaseClient = useSupabaseClient<Database>();
  const [msg, setMsg] = useState('');

  const handleSubmit = async (
    values: FormikHelper.ForgotPassword,
    formikHelpers: FormikHelpers<FormikHelper.ForgotPassword>
  ) => {
    const { setSubmitting } = formikHelpers;
    const { email } = values;
    setSubmitting(true);
    try {
      const { data, error } = await supabaseClient.auth.resetPasswordForEmail(email, {
        redirectTo,
      });

      // bad practise to log error here since it can be used to exploit existing emails
      setMsg('A reset link has been sent to your email');
    } catch (e) {
      // remove before final product
      console.log(e);
    }
    setSubmitting(false);
  };

  return (
    <Formik onSubmit={handleSubmit} initialValues={ForgotPasswordForm.initialValues}>
      {({ submitForm, isSubmitting }) => (
        <Form className={styles.form}>
          {!msg &&
            (!isSubmitting ? (
              <>
                <TextField label="Email" name="email" placeholder="Enter email" type="email" />
                <button type="submit">Send reset email</button>
              </>
            ) : (
              <ScaleLoader
                color="#FFFFFF"
                cssOverride={{ margin: 'auto auto' }}
                aria-label="Loading Spinner"
                data-testid="loader"
              />
            ))}

          {msg && <h2 className={styles.msg}>{msg}</h2>}
        </Form>
      )}
    </Formik>
  );
};

ForgotPasswordForm.initialValues = {
  email: '',
} as FormikHelper.ForgotPassword;

ForgotPasswordForm.validationSchema = object({
  email: string().email().required('An email is required'),
});

export default ForgotPasswordForm;
