import { Form, Formik, FormikHelpers } from 'formik';
import React, { useState } from 'react';
import { boolean, object, ref, string } from 'yup';

import AddressField from '@/components/fields/AddressField';
import CheckBoxField from '@/components/fields/CheckBoxField';
import LightSwitchField from '@/components/fields/LightSwitchField';
import Modal from 'react-modal';
import { ScaleLoader } from 'react-spinners';
import TermsAndConditions from '../ConsentForm';
import TextField from '@/components/fields/TextField';
import styles from './SignUpForm.module.scss';
import { useSupabaseClient } from '@supabase/auth-helpers-react';

interface Props {}

const redirectUri = process.env.NEXT_PUBLIC_SUPABASE_REDIRECT
  ? `${process.env.NEXT_PUBLIC_SUPABASE_REDIRECT}api/auth/callback`
  : undefined;

const SignUpForm = ({}: Props) => {
  const supabaseClient = useSupabaseClient<Database>();
  const [msg, setMsg] = useState('');
  const [termsOpen, setTermsOpen] = useState(false);
  const [abnLoading, setAbnLoading] = useState(false);
  const [abnVerified, setAbnVerified] = useState(false);
  const [abnData, setAbnData] = useState<AbnData | null>(null);

  const verifyAbn = async (abn: string, setFieldError: (field: string, message: string | undefined) => void) => {
    if (abn?.length !== 11) {
      setFieldError('abn', 'ABN must be 11 digits');
      return;
    }
    setAbnLoading(true);
    const body = JSON.stringify({ abn });

    try {
      const abnRes = await fetch('/api/abn/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body,
      })?.then(async (res) => await res.json());

      if (abnRes?.success && abnRes?.abnData) {
        setAbnVerified(true);
        setAbnData(abnRes.abnData as AbnData);
        setFieldError('abn', undefined);
        setAbnLoading(false);
        return;
      }
      setFieldError('abn', 'Invalid abn');
    } catch (e) {
      console.error(e);
      setFieldError('abn', 'An error occured validating your abn');
    }
    setAbnLoading(false);
  };

  const handleSubmit = async (
    values: FormikHelper.SignUpForm,
    formikHelpers: FormikHelpers<FormikHelper.SignUpForm>
  ) => {
    const { email, password, abn, address, addressData, phone } = values;
    const { setSubmitting, setFieldError } = formikHelpers;

    if (!abnVerified) {
      setFieldError('abn', 'you must verify your ABN');
      return;
    }

    setSubmitting(true);
    try {
      const { data, error } = await supabaseClient.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: redirectUri },
      });

      if (abnData) {
        const companyData = {
          abn: parseInt(abnData.Abn),
          data: abnData as unknown as Json,
        };

        await supabaseClient.from('company').upsert(companyData);
      }

      if (data?.user?.id) {
        const userRes = await supabaseClient.from('user_data').insert({
          abn: parseInt(abnData ? abnData.Abn : abn),
          address,
          address_data: addressData as Json,
          first_name: values?.firstName,
          last_name: values?.lastName,
          id: data.user.id,
          phone,
          is_donor: values?.userType === 'donor',
        });

        if (!userRes.error) {
          setMsg('Your account has been created, please check your emails click the activation link');
          return;
        }
      }
      setMsg('There has been an error creating your account please try again later');
    } catch (e) {
      // remove before final product
      console.log(e);
    }
    setSubmitting(false);
  };

  return (
    <Formik
      onSubmit={handleSubmit}
      initialValues={SignUpForm.initialValues}
      validationSchema={SignUpForm.validationSchema}>
      {({ values, isSubmitting, setFieldError }) => (
        <Form className={styles.form}>
          {(isSubmitting || msg) && (
            <div className={styles.loader}>
              {!msg ? (
                <ScaleLoader
                  color="#FFFFFF"
                  cssOverride={{ margin: 'auto auto' }}
                  aria-label="Loading Spinner"
                  data-testid="loader"
                />
              ) : (
                <p>{msg}</p>
              )}
            </div>
          )}
          <LightSwitchField name="userType" selections={['collector', 'donor']} />
          <div className={styles.half}>
            <TextField name="firstName" placeholder="First Name" type="text" />
            <TextField name="lastName" placeholder="Last Name" type="text" />
          </div>
          <TextField name="email" placeholder="Email" type="email" />
          <TextField name="phone" placeholder="Phone" type="tel" />
          <div className={styles.abnWrapper}>
            <TextField name="abn" placeholder="ABN" type="text" autoComplete="undefined" disabled={abnVerified} />
            {!abnVerified ? (
              !abnLoading ? (
                <button type="button" onClick={() => verifyAbn(values?.abn, setFieldError)}>
                  Verify
                </button>
              ) : (
                <ScaleLoader color="#FFFFFF" cssOverride={{ margin: 'auto auto' }} aria-label="Loading Spinner" />
              )
            ) : null}
          </div>
          <AddressField />
          <TextField name="password" placeholder="Password" type="password" autoComplete="new-password" />
          <TextField
            name="confirmPassword"
            placeholder="Confirm password"
            type="password"
            autoComplete="new-password"
          />
          <CheckBoxField
            name="termsAccepted"
            options={[
              {
                value: 'true',
                elem: (
                  <span>
                    Accept{' '}
                    <span className={styles.termsText} onClick={() => setTermsOpen(true)}>
                      Terms and conditions?
                    </span>
                  </span>
                ),
              },
            ]}
          />
          <button type="submit" className={styles.submit}>
            Submit
          </button>
          <Modal
            isOpen={termsOpen}
            onRequestClose={() => setTermsOpen(false)}
            overlayClassName={styles.overlay}
            className={styles.modal}>
            <TermsAndConditions setTermsOpen={setTermsOpen} />
          </Modal>
        </Form>
      )}
    </Formik>
  );
};

SignUpForm.initialValues = {
  userType: 'collector',
  email: '',
  phone: '',
  firstName: '',
  lastName: '',
  address: '',
  addressData: null,
  abn: '',
  password: '',
  confirmPassword: '',
  termsAccepted: false,
} as FormikHelper.SignUpForm;

SignUpForm.validationSchema = object({
  userType: string().required(),
  email: string().email().required('An email is required'),
  phone: string().min(10).max(13).required('A phone number is required'),
  firstName: string().required('Required'),
  lastName: string().required('Required'),
  address: string().required('Please enter an address'),
  addressData: object().required('You must select an address from the dropdown'),
  abn: string().min(11, 'ABN must be 11 digits').max(11, 'ABN must be 11 digits').required('an ABN is required'),
  termsAccepted: boolean().oneOf([true], 'You must accept the terms & conditions to use the app').required(),
  password: string().min(8).required('A password is required'),
  confirmPassword: string()
    .oneOf([ref('password')], 'Passwords must match')
    .required('Please confirm password'),
});

export default SignUpForm;
