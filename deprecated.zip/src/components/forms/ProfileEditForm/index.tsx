import { Form, Formik } from 'formik';
import { object, string } from 'yup';

import AddressField from '@/components/fields/AddressField';
import ImageField from '@/components/fields/ImageField';
import React from 'react';
import Router from 'next/router';
import TextField from '@/components/fields/TextField';
import styles from './ProfileEditForm.module.scss';
import { useSupabaseClient } from '@supabase/auth-helpers-react';

interface Props {
  initialData: Tables.UserData;
  setIsEditing?: React.Dispatch<React.SetStateAction<boolean>>;
}

const ProfileEditForm = ({ initialData, setIsEditing }: Props) => {
  const supabaseClient = useSupabaseClient();

  const onSubmit = async (values: FormikHelper.UserUpdateForm) => {
    const { data, error } = await supabaseClient.from('user_data').update(values).eq('id', initialData.id);

    if (error) {
      console.error('Error updating profile:', error);
    } else {
      Router.reload();
    }
  };

  return (
    <Formik
      initialValues={ProfileEditForm.initialVariables(initialData)}
      onSubmit={onSubmit}
      validationSchema={ProfileEditForm.validationSchema}>
      {({ isSubmitting, resetForm }) => (
        <Form className={styles.form}>
          <div className={styles.fieldWrapper}>
            <ImageField label="Avatar" name="avatar_url" uploadPath="avatar_images" />
          </div>
          <div className={styles.fieldWrapper}>
            <TextField label="First Name" name="first_name" placeholder="Enter first name" />
          </div>
          <div className={styles.fieldWrapper}>
            <TextField label="Last Name" name="last_name" placeholder="Enter last name" />
          </div>
          <div className={styles.fieldWrapper}>
            <TextField label="Phone" name="phone" placeholder="Enter phone number" />
          </div>
          <div className={styles.fieldWrapper}>
            <AddressField label="Address" name="address" dataName="address_data" placeholder="Enter address" />
          </div>
          <div className={styles.actions}>
            <button type="button" onClick={() => resetForm()}>
              Cancel
            </button>
            <button type="submit">Save</button>
          </div>
        </Form>
      )}
    </Formik>
  );
};

ProfileEditForm.initialVariables = (initialData: Tables.UserData): FormikHelper.UserUpdateForm => ({
  first_name: initialData.first_name || '',
  last_name: initialData.last_name || '',
  phone: initialData.phone || '',
  address: initialData.address || '',
  address_data: initialData.address_data || null,
  avatar_url: initialData.avatar_url || null,
  is_donor: initialData.is_donor || false,
  abn: initialData.abn || null,
});

ProfileEditForm.validationSchema = object({
  first_name: string().required('Required'),
  last_name: string().required('Required'),
  phone: string().min(10).max(13).required('A phone number is required'),
  address: string().required('Please enter an address'),
  address_data: object().required('You must select an address from the dropdown'),
});

export default ProfileEditForm;
