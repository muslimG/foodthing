import React, { ReactNode } from 'react';

import Header from '../Header';
import Navbar from '../Navbar';
import cc from 'classcat';
import styles from './pageWrapper.module.scss';

interface Props {
  children: ReactNode;
  backBtn?: boolean;
  headerRight?: JSX.Element;
  headerLeftText?: string;
  showNavbar?: boolean;
}

function PageWrapper({ children, backBtn = false, headerRight, headerLeftText, showNavbar = true }: Props) {
  return (
    <div className={cc({ [styles.pageWrapper]: true, [styles.noNavbar]: !showNavbar })}>
      <Header backBtn={backBtn} rightElement={headerRight} leftText={headerLeftText} />
      <div className={styles.content}>{children}</div>
      {showNavbar && <Navbar />}
    </div>
  );
}

export default PageWrapper;
