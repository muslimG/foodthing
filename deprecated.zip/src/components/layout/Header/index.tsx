import BackIcon from '@/components/icons/svg/tabler-arrow-narrow-left.svg';
import React from 'react';
import styles from './header.module.scss';
import { useRouter } from 'next/router';

interface Props {
  backBtn: boolean;
  leftText?: string; // doesn't show if backBtn is true
  rightElement?: JSX.Element;
}

function Header({ rightElement, backBtn = false, leftText }: Props) {
  const router = useRouter();

  return (
    <div className={styles.wrapper}>
      <div className={styles.content}>
        {!backBtn ? (
          <h2 className={styles.brand} onClick={() => router.push('/home')}>
            {leftText || 'ReFood'}
          </h2>
        ) : (
          <BackIcon className={styles.back} onClick={() => router.back()} />
        )}
        {rightElement}
      </div>
    </div>
  );
}

export default Header;
