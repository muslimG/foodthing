import BellIcon from '@/components/icons/svg/tabler-bell.svg';
import ChatIcon from '@/components/icons/svg/tabler-chat.svg';
import HomeIcon from '@/components/icons/svg/tabler-home.svg';
import Link from 'next/link';
import ProfileIcon from '@/components/icons/svg/tabler-profile.svg';
import React from 'react';
import SaladIcon from '@/components/icons/svg/tabler-salad.svg';
import styles from './navbar.module.scss';
import { useRouter } from 'next/router';

interface Props {}

function Navbar({}: Props) {
  const router = useRouter();
  const path = router?.pathname;

  return (
    <nav className={styles.navbar}>
      <div className={styles.navbarContainer}>
        <Link href="/home" className={path === '/home' ? styles.active : ''}>
          <HomeIcon />
          <p>Home</p>
        </Link>
        <Link href="/donations" className={path?.startsWith('/donations') ? styles.active : ''}>
          <SaladIcon />
          <p>Donations</p>
        </Link>
        <Link href="/notifications" className={path?.startsWith('/notifications') ? styles.active : ''}>
          <BellIcon />
          <p>Updates</p>
        </Link>
        <Link href="/chat" className={path?.startsWith('/chat') ? styles.active : ''}>
          <ChatIcon />
          <p>Chat</p>
        </Link>
        <Link href="/profile" className={path === '/profile' ? styles.active : ''}>
          <ProfileIcon />
          <p>Profile</p>
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;
