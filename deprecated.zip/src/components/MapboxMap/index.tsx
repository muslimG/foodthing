import React, { useRef, useState } from 'react';

import mapboxgl from 'mapbox-gl'; // eslint-disable-line import/no-webpack-loader-syntax
import styles from './MapboxMap.module.scss';
import { useEffectOnce } from 'react-use';

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN || '';

interface Props {
  longitude: number;
  latitude: number;
  initialZoom?: number;
  onMove?: () => void;
  markers?: Mapbox.Marker[];
  className?: string;
}

export const MapboxMap: React.FC<Props> = ({ longitude, latitude, initialZoom = 15, onMove, markers, className }) => {
  const mapContainer = useRef<any>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleDarkMode = () => {
    // Toggle the mode to enable dark mode for map
    setIsDarkMode(!isDarkMode);
    const newStyle = isDarkMode ? 'mapbox://styles/mapbox/streets-v12' : 'mapbox://styles/mapbox/dark-v11';
    map.current?.setStyle(newStyle);
  };

  const isoChroneAPI = async () => {
    const urlBase = 'https://api.mapbox.com/isochrone/v1/mapbox/';
    const profile = 'driving';
    const meters = 5000;

    try {
      const res = await fetch(
        `${urlBase}${profile}/${longitude},${latitude}?contours_meters=${meters}&polygons=true&access_token=${mapboxgl.accessToken}`,
        { method: 'GET' }
      );
      if (!res.ok) {
        throw new Error('Network error');
      }
      const nearbyData = await res.json();
      console.log(nearbyData); //debug

      const featureCollection = nearbyData.features;

      // Add source to map
      map.current?.addSource('isochroneSource', {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: featureCollection,
        },
      });

      //  Display isochrone contours
      map.current?.addLayer({
        id: 'isochroneLayer',
        type: 'fill',
        source: 'isochroneSource',
        paint: {
          'fill-color': '#ca7b01',
          'fill-opacity': 0.3,
        },
      });
    } catch (error) {
      console.error('Error fetching isochrone data:', error);
    }
  };

  useEffectOnce(() => {
    if (map.current) return; // initialize map only once

    const isPast6PM = new Date().getHours() >= 18;

    const initialStyle = isPast6PM ? 'mapbox://styles/mapbox/dark-v11' : 'mapbox://styles/mapbox/streets-v12';
    setIsDarkMode(isPast6PM);

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: initialStyle,
      center: [longitude, latitude],
      zoom: initialZoom,
    });

    // Add Navigation Controls to the map (+, -, Compass)
    const navigationControl = new mapboxgl.NavigationControl({ visualizePitch: true });
    map.current.addControl(navigationControl);

    const initialPopup = new mapboxgl.Popup({ className: styles.pin }).setHTML(`<h3>You are here</h3>`);

    new mapboxgl.Marker({ color: '#006eff' })
      .setLngLat([longitude, latitude])
      .setPopup(initialPopup)
      .addTo(map.current!);

    // Add marker to each donation with linked information
    markers?.forEach((marker) => {
      const popup = new mapboxgl.Popup({ className: styles.pin }).setHTML(
        `<h3>${marker.title}</h3> <br /> 
         <p> ${marker.location} </p> <br /> 
         <div class="${styles.pinAnchorContainer}">
         <a class="${styles.pinAnchor}" href="/donations/view/${marker.id}" target="_self" title="More Information">Tell me more!</a> <br /> <br />
         <a class="${styles.pinAnchor}" href="https://www.google.com/maps?q=${marker.lat},${marker.lng}" target="_blank" rel="noopener noreferrer" title="Open in Google Maps" class="popup_link"'>Open in Google Maps</a>
         </div>`
      );

      if (marker?.lng && marker?.lat) {
        const markerElement = new mapboxgl.Marker({ color: '#58ab5b' })
          .setLngLat([marker.lng, marker.lat])
          .setPopup(popup)
          .addTo(map.current!);

        markerElement.getElement().addEventListener('click', () => {
          // Toggle popup when the marker is clicked
          markerElement.togglePopup();
        });
      }
    });

    map?.current.on('move', () => onMove?.());

    // isoChroneAPI();
  });

  // Go back to business location
  const goToOriginalLocation = () => {
    if (map.current) {
      map.current?.flyTo({ center: [longitude, latitude], zoom: initialZoom, speed: 2 });
    }
  };

  return (
    <div className={className ?? styles.wrapper}>
      <div ref={mapContainer} className={styles.map} />

      <button className={styles.mode} onClick={toggleDarkMode}>
        {isDarkMode ? 'Light' : 'Dark'}
      </button>

      <button className={styles.reCenter} onClick={goToOriginalLocation}>
        Re-center
      </button>
    </div>
  );
};

export default MapboxMap;
