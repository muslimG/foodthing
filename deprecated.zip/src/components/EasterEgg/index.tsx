import React, { useEffect, useRef, useState } from 'react';

import Image from '@/components/Image';
import Matter from 'matter-js';
import styles from './styles.module.scss';

const STATIC_DENSITY = 15;
const PARTICLE_SIZE = 20;
const PARTICLE_BOUNCYNESS = 0.9;

const EasterEggMatter = () => {
  const boxRef = useRef<any>(null);
  const canvasRef = useRef<any>(null);

  const [constraints, setContraints] = useState<any>();
  const [scene, setScene] = useState<any>();

  const [someStateValue, setSomeStateValue] = useState<any>(false);

  const handleResize = () => {
    setContraints(boxRef.current.getBoundingClientRect());
  };

  const handleClick = () => {
    setSomeStateValue(!someStateValue);
  };

  useEffect(() => {
    let Engine = Matter.Engine;
    let Render = Matter.Render;
    let World = Matter.World;
    let Bodies = Matter.Bodies;

    let engine = Engine.create({});

    const cw = document.body.clientWidth;
    const ch = document.body.clientHeight;

    let render = Render.create({
      element: boxRef.current,
      engine: engine,
      canvas: canvasRef.current,
      options: {
        background: 'transparent',
        wireframes: false,
        width: cw,
        height: ch,
      },
    });

    const floor = Bodies.rectangle(0, 0, 0, STATIC_DENSITY, {
      isStatic: true,
      render: {
        fillStyle: 'transparent',
      },
    });

    const wallLeft = Bodies.rectangle(0, 0, STATIC_DENSITY, constraints?.height || 0, {
      isStatic: true,
      render: {
        fillStyle: 'blue',
      },
    });

    const wallRight = Bodies.rectangle(constraints?.width || 0, 0, STATIC_DENSITY, constraints?.height || 0, {
      isStatic: true,
      render: {
        fillStyle: 'green',
      },
    });

    World.add(engine.world, [floor, wallLeft, wallRight]);

    // add mouse control
    const mouse = Matter.Mouse.create(render.canvas);
    const mouseConstraint = Matter.MouseConstraint.create(engine, {
      mouse: mouse,
      constraint: {
        stiffness: 0.2,
        render: {
          visible: true,
        },
      },
    });

    // keep the mouse in sync with rendering
    render.mouse = mouse;

    World.add(engine.world, mouseConstraint);

    Engine.run(engine);
    Render.run(render);

    setContraints(boxRef.current.getBoundingClientRect());
    setScene(render);

    window.addEventListener('resize', handleResize);
  }, [constraints?.height, constraints?.width]);

  useEffect(() => {
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    if (constraints) {
      let { width, height } = constraints;

      // Dynamically update canvas and bounds
      scene.bounds.max.x = width;
      scene.bounds.max.y = height;
      scene.options.width = width;
      scene.options.height = height;
      scene.canvas.width = width;
      scene.canvas.height = height;

      // Dynamically update floor
      const floor = scene.engine.world.bodies[0];

      Matter.Body.setPosition(floor, {
        x: width / 2,
        y: height + STATIC_DENSITY / 2,
      });

      Matter.Body.setVertices(floor, [
        { x: 0, y: height },
        { x: width, y: height },
        { x: width, y: height + STATIC_DENSITY },
        { x: 0, y: height + STATIC_DENSITY },
      ]);

      const wallLeft = scene.engine.world.bodies[1];

      Matter.Body.setPosition(wallLeft, {
        x: 0 - STATIC_DENSITY / 2,
        y: height / 2,
      });

      Matter.Body.setVertices(wallLeft, [
        { x: 0, y: 0 },
        { x: 0, y: height },
        { x: 0 - STATIC_DENSITY, y: height },
        { x: 0 - STATIC_DENSITY, y: 0 },
      ]);

      const wallRight = scene.engine.world.bodies[2];
      0;

      Matter.Body.setPosition(wallRight, {
        x: width + STATIC_DENSITY / 2,
        y: height / 2,
      });

      Matter.Body.setVertices(wallRight, [
        { x: width, y: 0 },
        { x: width, y: height },
        { x: width + STATIC_DENSITY, y: height },
        { x: width + STATIC_DENSITY, y: 0 },
      ]);
    }
  }, [scene, constraints]);

  useEffect(() => {
    // Add a new "ball" everytime `someStateValue` changes
    if (scene) {
      let { width } = constraints;
      let randomX = Math.floor(Math.random() * -width) + width;
      Matter.World.add(
        scene.engine.world,
        Matter.Bodies.circle(randomX, -PARTICLE_SIZE, PARTICLE_SIZE, {
          restitution: PARTICLE_BOUNCYNESS,
          render: {
            sprite: {
              texture: '/assets/images/easteregg.png',
              xScale: 0.34,
              yScale: 0.32,
            },
          },
        })
      );
    }
  }, [constraints, scene, someStateValue]);

  return (
    <div
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
      }}
      // onClick={() => handleClick()}
    >
      <div
        ref={boxRef}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          // pointerEvents: 'none',
        }}>
        <Image className={styles.mainLogoFormat} src="/assets/images/logo.png" alt="logo" onClick={handleClick} />
        <canvas ref={canvasRef} style={{ cursor: 'pointer' }} />
      </div>
    </div>
  );
};

export default EasterEggMatter;
