import AlarmIcon from '@/components/icons/svg/tabler-alarm.svg';
import BoxIcon from '@/components/icons/svg/tabler-box-seam.svg';
import CategoryIcon from '@/components/icons/svg/tabler-category.svg';
import DonationDynamicIcon from '../DonationDynamicIcon';
import PinIcon from '@/components/icons/svg/tabler-map-pin.svg';
import React from 'react';
import WeightIcon from '@/components/icons/svg/tabler-weight.svg';
import cc from 'classcat';
import { convertToGeocodeFeature } from '@/lib/utils';
import styles from './index.module.scss';
import useTimeLeft from '@/hooks/useTimeLeft';

interface Props {
  title: string | null;
  weight: number | null;
  unit: string | null;
  quantity: number | null;
  duration: string | null;
  locationData: Json | null;
  category: string | null;
  subCategory?: string | null;
  image?: string | null;
  profilePage?: boolean;
}

const Donation = ({
  title,
  weight,
  unit,
  quantity,
  duration,
  locationData,
  category,
  subCategory,
  profilePage = false,
}: Props) => {
  const timeLeft = useTimeLeft(duration);
  const formattedLocation = convertToGeocodeFeature(locationData);
  const suburb = formattedLocation?.context?.find((ctx) => ctx?.id?.includes('locality') || ctx?.id?.includes('place'))
    ?.text;

  return (
    /* Example below shows styles.profileWrapper will only be applied if profilePage prop is true */
    <div className={cc({ [styles.wrapper]: true, [styles.profileWrapper]: profilePage })}>
      <div className={styles.iconWrapper}>
        <DonationDynamicIcon category={category} />
      </div>
      <div className={styles.content}>
        <h3 className={styles.title}>{title}</h3>
        <div className={styles.info}>
          <div className={cc([styles.dataBlock, styles.halfSize])}>
            <WeightIcon className={styles.icon} />
            <p className={styles.dataValue}>
              {weight} {!quantity ? unit : 'kg'}
            </p>
          </div>
          {quantity && (
            <div className={cc([styles.dataBlock, styles.halfSize])}>
              <BoxIcon className={styles.icon} />
              <p className={styles.dataValue}>{quantity} qty</p>
            </div>
          )}
          {/* Also example this component will only be rendered if the profilePage prop is true */}
          {!profilePage && (
            <div className={cc([styles.dataBlock, styles.halfSize])}>
              <AlarmIcon className={styles.icon} />
              <p className={styles.dataValue}>{timeLeft}</p>
            </div>
          )}
          <div className={cc([styles.dataBlock, styles.halfSize])}>
            <PinIcon className={styles.icon} />
            <p className={styles.dataValue}>{suburb}</p>
          </div>
          <div className={styles.dataBlock}>
            <CategoryIcon className={styles.icon} />
            <div>
              <p className={styles.dataValue}>{category}</p>
              <p className={styles.dataValue}>{subCategory}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Donation;
