import Donation from './index';
import React from 'react';
import { render } from '@testing-library/react';

describe('<Dontation />', () => {
  it('renders', () => {
    const component = (
      <Donation title="Fish Sticks" weight={4.2} unit="kg" duration="5.2h" locationData={null} category="Fish" />
    );

    const { getByText } = render(component);

    expect(getByText('Fish Sticks')).toBeDefined();
  });
});
