import { useEffect } from 'react';
import { useWindowSize } from 'react-use';

const useWindowHeight = () => {
  const { height } = useWindowSize();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      document.documentElement.style.setProperty('--window-height', `${height}px`);
    }
  }, [height]);
};

export default useWindowHeight;
