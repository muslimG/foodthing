import { PostgrestSingleResponse, User } from '@supabase/supabase-js';
import { SupabaseClient, useSupabaseClient, useUser } from '@supabase/auth-helpers-react';
import { useEffect, useState } from 'react';

type GenericQuery<T> = (
  supabaseClient: SupabaseClient<Database>,
  user: User | null
) => Promise<PostgrestSingleResponse<T>>;

const useSupabaseQuery = <T,>(query: GenericQuery<T>) => {
  const supabaseClient = useSupabaseClient<Database>();
  const [data, setData] = useState<T | null>(null);
  const user = useUser();

  useEffect(() => {
    async function loadData() {
      const { data } = await query?.(supabaseClient, user);
      setData(data);
    }

    if (user) loadData();
  }, [user, supabaseClient, query]);

  return [data];
};

export default useSupabaseQuery;
