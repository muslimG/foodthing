import { differenceInDays, differenceInHours, differenceInMinutes } from 'date-fns';

import { useMemo } from 'react';

const useTimeLeft = (duration?: string | null) => {
  const timeLeft = useMemo(() => {
    if (!duration) return 'Expired';

    const diffInDays = differenceInDays(new Date(duration), new Date());
    const diffInHours = differenceInHours(new Date(duration), new Date());
    if (diffInHours <= 1 && diffInHours >= 0) {
      return `${differenceInMinutes(new Date(duration), new Date())} minute`;
    }
    if (diffInDays >= 1) {
      return `${diffInDays} days`;
    } else if (diffInDays < 1 && diffInDays >= 0) {
      return `${diffInHours} hours`;
    } else {
      return 'Expired';
    }
  }, [duration]);

  return timeLeft;
};

export default useTimeLeft;
