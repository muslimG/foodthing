import React, { useEffect } from 'react';

const useNotificationSW = (
  setSubscription: React.Dispatch<React.SetStateAction<PushSubscription | null>>,
  setIsSubscribed: React.Dispatch<React.SetStateAction<boolean>>,
  setRegistration: React.Dispatch<React.SetStateAction<ServiceWorkerRegistration | null>>
) => {
  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator && (window as any).workbox !== undefined) {
      // run only in browser
      navigator.serviceWorker.ready.then((reg) => {
        reg.pushManager.getSubscription().then((sub) => {
          if (sub && !(sub.expirationTime && Date.now() > sub.expirationTime - 5 * 60 * 1000)) {
            setSubscription(sub);
            setIsSubscribed(true);
          }
        });
        setRegistration(reg);
      });
    }
  }, [setIsSubscribed, setRegistration, setSubscription]);
};

export default useNotificationSW;
