import { add, format } from 'date-fns';
import { getChatByDonationId, getDonationById, updateChatUnreadByDonationId } from '@/lib/queries';
import { useEffect, useRef, useState } from 'react';
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react';

import DonationDynamicIcon from '@/components/DonationDynamicIcon';
import Link from 'next/link';
import PageWrapper from '@/components/layout/PageWrapper';
import cc from 'classcat';
import styles from './index.module.scss';
import { useRouter } from 'next/router';

type ChatInsert = Omit<Tables.ChatMessages, 'id'>;

type Messages = Array<ChatInsert | Tables.ChatMessages>;

const ChatPerUser = () => {
  const supabaseClient = useSupabaseClient<Database>();
  const user = useUser();
  const router = useRouter();
  const donationId = Array.isArray(router.query?.donationId) ? router.query?.donationId[0] : router.query?.donationId;
  const [messages, setMessages] = useState<Messages>([]);
  const [donation, setDonation] = useState<Tables.Donations | null>(null);
  const [newMessage, setNewMessage] = useState('');
  // must be useState rather than useRef to trigger re-render
  const [scrollRef, setScrollRef] = useState<HTMLDivElement | null>(null);
  const textRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    async function loadMessages() {
      if (!donationId || !user?.id) return;
      const { data: donationData } = await getDonationById(supabaseClient, donationId);

      if (!donationData?.collector_id) return;

      const { data } = await getChatByDonationId(
        supabaseClient,
        donationId,
        donationData?.user_id,
        donationData?.collector_id,
        donationData?.collect_date
      );

      donationData && setDonation(donationData);
      data && setMessages(data);

      // update all unread chats to be read
      await updateChatUnreadByDonationId(supabaseClient, donationId, user?.id);

      supabaseClient
        .channel('get-new-messages')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'chat_messages',
            filter: `donation_id=eq.${donationId}`,
          },
          async (payload) => {
            const newMsg = payload.new as Tables.ChatMessages;
            if (!donationData?.collector_id) return;

            const { data, error } = await getChatByDonationId(
              supabaseClient,
              donationId,
              donationData?.user_id,
              donationData?.collector_id,
              donation?.collect_date
            );
            data && setMessages(data);
          }
        )
        .subscribe();
    }

    if (donationId && user?.id) loadMessages();

    // when component destroys, unsubscribe from channel. Important!
    return () => {
      supabaseClient.channel('get-new-messages').unsubscribe();
    };
  }, [user, donationId, supabaseClient, donation?.collect_date]);

  useEffect(() => {
    if (!!messages?.length && scrollRef?.scrollHeight) {
      scrollRef.scrollTop = scrollRef.scrollHeight;
      resizeTextArea();
    }
  }, [messages, scrollRef]);

  const handleSendMessage = async () => {
    const senderID = user?.id; // Use the ID from the logged-in user
    if (!senderID || !donationId) {
      console.error('User not logged in!');
      return;
    }

    const newMessageData: ChatInsert = {
      chat_text: newMessage,
      sender_id: senderID,
      donation_id: parseInt(donationId),
      chat_date: new Date().toISOString(),
      is_read: false,
    };

    const { data, error } = await supabaseClient.from('chat_messages').insert(newMessageData);

    if (error) {
      console.error('Error sending message:', error);
      return;
    }

    // Add the new message to the local messages state
    setMessages([...messages, newMessageData]);
    setNewMessage('');
  };

  const getPrettyTimestamp = (chatTimestamp: string) => {
    const isoDateTime = new Date(chatTimestamp);
    const localeDateTime = add(isoDateTime, { hours: 8 });
    const timestamp = format(localeDateTime, 'LLL do h:mm aaa');
    return timestamp;
  };

  const resizeTextArea = () => {
    if (textRef?.current) {
      textRef.current.style.height = ``;
      if (textRef.current.scrollHeight <= 116) {
        textRef.current.style.height = `${textRef.current.scrollHeight + 4}px`;
      } else {
        textRef.current.style.height = `${116 + 4}px`;
      }
    }
  };

  return (
    <PageWrapper
      backBtn
      headerRight={
        <>
          {donation?.title && (
            <Link className={styles.headerRightContainer} href={`/donations/view/${donation?.id}`} passHref>
              <p className={styles.donationTitle}>{donation?.title}</p>
              <DonationDynamicIcon category={donation?.category} className={styles.categoryIcon} />
            </Link>
          )}
        </>
      }
      showNavbar={false}>
      <div className={styles.wrapper}>
        <div className={styles.center} ref={(ref) => setScrollRef(ref)}>
          <div className={styles.messages}>
            {messages?.map((message, idx) => (
              <div
                key={`${message?.chat_date}-${idx}`}
                className={cc({ [styles.message]: true, [styles.sent]: message?.sender_id == user?.id })}>
                {message.chat_text}
                {message?.chat_date && <div className={styles.timestamp}>{getPrettyTimestamp(message?.chat_date)}</div>}
              </div>
            ))}
          </div>
          <div className={styles.inputArea}>
            <textarea
              className={styles.messageTextarea}
              value={newMessage}
              onChange={(e) => {
                setNewMessage(e.target.value);
                resizeTextArea();
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              ref={textRef}
              placeholder="Type a message..."
              rows={1}
            />
            <button className={styles.sendButton} onClick={handleSendMessage}>
              Send
            </button>
          </div>
        </div>
      </div>
    </PageWrapper>
  );
};

export default ChatPerUser;
