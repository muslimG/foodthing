import { getChatDonations, getCurrentUserData, getLastChatByDonationId, getOtherUserData } from '@/lib/queries';
import { useEffect, useState } from 'react';
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react';

import DonationDynamicIcon from '@/components/DonationDynamicIcon';
import PageWrapper from '@/components/layout/PageWrapper';
import { ScaleLoader } from 'react-spinners';
import cc from 'classcat';
import { formatDateDifferenceShort } from '@/lib/utils';
import styles from './index.module.scss';
import { useRouter } from 'next/router';

type OtherUsers = Array<
  | {
      donation_id: number;
      first_name?: string | null;
      last_name?: string | null;
      is_read?: boolean | null;
      chat_text?: string | null;
      chat_date?: string | null;
      sender_id?: string | null;
    }
  | undefined
>;

// Define the ChatList component
const ChatList = () => {
  const user = useUser();
  const supabaseClient = useSupabaseClient();
  const [chats, setChats] = useState<Tables.Donations[] | null>(null);
  const [otherUsers, setOtherUsers] = useState<OtherUsers | null>(null);
  const router = useRouter();

  useEffect(() => {
    async function fetchChats() {
      // Fetch all donations which either you are dontating or collecting
      const { data, error } = await getChatDonations(supabaseClient, user);
      // Get user data to determine whether donor or collector
      const { data: userData } = await getCurrentUserData(supabaseClient, user);

      const chatUsers =
        data &&
        (await Promise.all(
          data?.map(async (donation) => {
            if (donation?.user_id && donation?.collector_id && userData) {
              const { is_donor } = userData;

              // Get other user data relevant to each donation chat
              const { data: otherUser } = await getOtherUserData(
                supabaseClient,
                is_donor ? donation.collector_id : donation.user_id
              );

              // Get the most recent message relevant to each donation chat
              const { data: chatInfo } = await getLastChatByDonationId(
                supabaseClient,
                donation.id.toString(),
                donation.collect_date
              );

              return {
                donation_id: donation?.id,
                first_name: otherUser?.first_name,
                last_name: otherUser?.last_name,
                is_read: chatInfo?.[0]?.is_read,
                chat_date: chatInfo?.[0]?.chat_date,
                sender_id: chatInfo?.[0]?.sender_id,
                chat_text: chatInfo?.[0]?.chat_text,
              };
            }
          })
        ));

      setOtherUsers(chatUsers);

      // Handle potential errors during data fetching
      if (error) {
        console.error('Error fetching users:', error);
      } else {
        // Update the state with fetched users
        setChats(data);
      }
    }
    if (user) fetchChats();
  }, [user, supabaseClient]);

  // Render the chat list UI
  return (
    <PageWrapper headerLeftText="Chats">
      <div className={styles.wrapper}>
        {/* Map over the list of users and render each user */}
        {chats ? (
          chats?.map((donation) => {
            const otherUser = otherUsers?.find((user) => user?.donation_id === donation?.id);
            const newMsg = !!otherUser?.chat_text && !otherUser?.is_read && otherUser?.sender_id !== user?.id;
            return (
              <div key={donation?.id} className={styles.userItem} onClick={() => router.push(`/chat/${donation?.id}`)}>
                <DonationDynamicIcon category={donation?.category} className={styles.donationIcon} />

                <div className={styles.titleAndMessage}>
                  <div className={styles.titleContainer}>
                    <p className={styles.title}>
                      {donation?.title} - {otherUser?.first_name}
                      {newMsg && <span className={styles.newMessage} />}
                    </p>
                  </div>

                  {!!otherUser?.chat_text && (
                    <div className={cc({ [styles.messageWrapper]: true, [styles.boldMsg]: newMsg })}>
                      <p className={styles.lastMessage}>
                        {otherUser?.sender_id === user?.id && 'You: '}
                        {otherUser?.chat_text}
                      </p>
                      <span className={styles.timestamp}>{formatDateDifferenceShort(otherUser?.chat_date, true)}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <ScaleLoader
            color="#58ab5b"
            cssOverride={{ margin: 'auto auto' }}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
        )}
        {chats && !chats?.length && (
          <p className={styles.noChats}>
            You currently have no chats.
            <br />
            Chats for donations that are pending collection.
          </p>
        )}
      </div>
    </PageWrapper>
  );
};

// Export the ChatList component for use in other parts of the application
export default ChatList;
