import React from 'react';
import styles from './index.module.scss';

interface Props {}

const Index = ({}: Props) => {
  return (
    <div className={styles.wrapper}>
      <div className={styles.center}>
        <h1 className={styles.heading}>You are offline.</h1>
        <p className={styles.offlineMsg}>This application requires internet access to function correctly</p>
      </div>
    </div>
  );
};

export default Index;
