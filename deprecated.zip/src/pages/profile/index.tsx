import React, { useState } from 'react';
import {
  getCollectorPendingDonations,
  getCurrentUserData,
  getDonatorCompletedDonations,
  getDonatorPendingDonations,
  getCollectorCompletedDonations,
} from '@/lib/queries';

import Donation from '@/components/Donation';
import Image from '@/components/Image';
import Link from 'next/link';
import LogoutIcon from '@/components/icons/svg/tabler-logout.svg';
import PageWrapper from '@/components/layout/PageWrapper';
import ProfileEditForm from '@/components/forms/ProfileEditForm';
import SingleActionModal from '@/components/modals/SingleActionModal';
import styles from './index.module.scss';
import { useRouter } from 'next/router';
import { useSupabaseClient } from '@supabase/auth-helpers-react';
import useSupabaseQuery from '@/hooks/useSupabaseQuery';

interface Props {}

const Profile = ({}: Props) => {
  const router = useRouter();
  const [tab, setCurrentTab] = useState(1);
  const [deleteModal, setDeleteModal] = useState(false);
  const supabaseClient = useSupabaseClient<Database>();

  const [userData] = useSupabaseQuery(getCurrentUserData);
  const [pendingDonations] = useSupabaseQuery(getDonatorPendingDonations);
  const [completedDonations] = useSupabaseQuery(getDonatorCompletedDonations);
  const [pendingCollections] = useSupabaseQuery(getCollectorPendingDonations);
  const [completedCollections] = useSupabaseQuery(getCollectorCompletedDonations);

  const avatarSrc = userData?.avatar_url
    ? supabaseClient.storage.from('imageFile').getPublicUrl(userData.avatar_url).data.publicUrl
    : '/assets/images/logo.png';

  const handleSignout = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    await supabaseClient.auth.signOut();
    router.push('/');
  };

  const handleDeleteAccount = async () => {
    try {
      // Delete user from authentication system
      const res = await fetch('/api/auth/delete');
      const deleteRes = await res.json();

      if (deleteRes.success) {
        await supabaseClient.auth.signOut();
        router.reload();
        return;
      }
    } catch (error) {
      console.error('An unexpected error occurred:', error);
    }
  };

  const handleTabChange = async (idx: number) => {
    setCurrentTab(idx);
  };

  const donationsToShow = tab === 1 ? pendingDonations : completedDonations;
  const collectionsToShow = tab === 1 ? pendingCollections : completedCollections;

  return (
    <PageWrapper headerRight={<LogoutIcon onClick={handleSignout} />}>
      <div className={styles.wrapper}>
        <div className={styles.profileBanner}>
          {avatarSrc && <Image alt="User Avatar" src={avatarSrc} className={styles.avatarImage} />}
          <div className={styles.profileData}>
            <h3>
              {userData?.first_name} {userData?.last_name}
            </h3>
            <p>ABN: {userData?.abn}</p>
          </div>
          <div className={styles.actions}>
            <button className={styles.delete} onClick={() => setDeleteModal(true)}>
              Delete Profile
            </button>
          </div>
        </div>
        <Link href="/reports" className={styles.reportsBtn}>
          <button type="button">{userData?.is_donor ? 'Completed' : 'Collected'} donations report suite</button>
        </Link>

        <div className={styles.tabSwitcher}>
          <div className={styles.switcherBg} style={{ left: `${-33.3333 + 33.3333 * tab}%` }} />
          <button onClick={() => handleTabChange(1)} className={tab == 1 ? styles.activeTab : styles.inactiveTab}>
            Pending
          </button>
          <button onClick={() => handleTabChange(2)} className={tab == 2 ? styles.activeTab : styles.inactiveTab}>
            Completed
          </button>
          <button onClick={() => handleTabChange(3)} className={tab == 3 ? styles.activeTab : styles.inactiveTab}>
            Settings
          </button>
        </div>

        <div className={styles.donColDiv}>
          {(tab === 1 || tab === 2) && !userData?.is_donor && (
            <div className={styles.collectorDiv}>
              {!!collectionsToShow?.length ? (
                collectionsToShow?.map((donation) => (
                  <Link
                    className={styles.cleanLink}
                    key={`${donation.title}-${donation.id}`}
                    href={`donations/view/${donation?.id}`}>
                    <Donation
                      profilePage
                      title={donation.title}
                      weight={donation.amount}
                      unit={donation.unit}
                      quantity={donation.quantity}
                      duration={donation.end_date}
                      locationData={donation.location_data}
                      category={donation.category}
                    />
                  </Link>
                ))
              ) : (
                <div className={styles.historyEmpty}>
                  <p>No donations collected</p>
                </div>
              )}
            </div>
          )}

          {(tab === 1 || tab === 2) && !!userData?.is_donor && (
            <div className={styles.donatorDiv}>
              {!!donationsToShow?.length ? (
                donationsToShow?.map((donation) => (
                  <Link
                    className={styles.cleanLink}
                    key={`${donation.title}-${donation.id}`}
                    href={`donations/view/${donation?.id}`}>
                    <Donation
                      profilePage
                      title={donation.title}
                      weight={donation.amount}
                      unit={donation.unit}
                      quantity={donation.quantity}
                      duration={donation.end_date}
                      locationData={donation.location_data}
                      category={donation.category}
                    />
                  </Link>
                ))
              ) : (
                <div className={styles.historyEmpty}>
                  <p>No donations created</p>
                </div>
              )}
            </div>
          )}

          {tab === 3 && userData && <ProfileEditForm initialData={userData} />}
        </div>
        <SingleActionModal
          isOpen={deleteModal}
          setIsOpen={setDeleteModal}
          title="Are you sure you want to delete your account?"
          bodyText="You will not be able to restore it once deleted"
          onConfirm={handleDeleteAccount}
        />
      </div>
    </PageWrapper>
  );
};

export default Profile;
