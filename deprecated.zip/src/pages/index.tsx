import React, { useState } from 'react';

import Image from '@/components/Image';
import Link from 'next/link';
import LoginForm from '@/components/forms/LoginForm';
import styles from './index.module.scss';

interface Props {}

const Index = ({}: Props) => {
  return (
    <div className={styles.wrapper}>
      <div className={styles.center}>
        <Image src="/assets/images/logo.png" alt="logo" className={styles.logo} />
        <h1 className={styles.heading}>ReFood</h1>
        <LoginForm />
        <div className={styles.alternate}>
          <div className={styles.fakeHr} />
          <span className={styles.or}>or</span>
        </div>
        <Link href="/sign-up" className={styles.createAccount}>
          create an account
        </Link>
      </div>
      <Link href="/forgot-password" className={styles.forgotPassword}>
        forgot password?
      </Link>
      <Link href="/privacy" className={styles.privacy}>
        Privacy Policy
      </Link>
    </div>
  );
};

export default Index;
