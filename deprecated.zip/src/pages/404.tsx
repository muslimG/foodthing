import Link from 'next/link';
import PageWrapper from '@/components/layout/PageWrapper';
import React from 'react';
import styles from './index.module.scss';

const Error404 = () => {
  return (
    <PageWrapper>
      <div className={styles.wrapper}>
        <div className={styles.center}>
          <h1 className={styles.heading}>Oops the page you loaded doesn&apos;t exist yet!</h1>
          <Link href="/">
            <button>Back to home?</button>
          </Link>
        </div>
      </div>
    </PageWrapper>
  );
};

export default Error404;
