import NewDonation from './[id]';

export default NewDonation;
