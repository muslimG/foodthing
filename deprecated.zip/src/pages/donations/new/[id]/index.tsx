import * as yup from 'yup';

import { Form, FormikHelpers } from 'formik';
import React, { useEffect, useState } from 'react';
import { categoryOptions, subcategoryOptions, weightOptions } from 'src/lib/donationHelpers';
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react';

import AddressField from '@/components/fields/AddressField';
import DateField from '@/components/fields/DateField';
import { Formik } from 'formik';
import ImageField from '@/components/fields/ImageField';
import NumberField from '@/components/fields/NumberField';
import PageWrapper from '@/components/layout/PageWrapper';
import SelectField from '@/components/fields/SelectField';
import TextField from '@/components/fields/TextField';
import styles from './index.module.scss';
import { useRouter } from 'next/router';

const NewDonation = () => {
  const supabaseClient = useSupabaseClient<Database>();
  const user = useUser();
  const router = useRouter();
  const [startData, setStartData] = useState<Tables.Donations | null>(null);
  const [imageSrc, setImageSrc] = useState<string>('');

  const donationLink = Array.isArray(router.query.id) ? router.query.id[0] : router.query.id;
  const donationId = donationLink ? (donationLink.includes('-') ? donationLink.split('-')?.[0] : donationLink) : null;
  const action = donationLink ? (donationLink.includes('-') ? donationLink.split('-')?.[1] : null) : null;

  useEffect(() => {
    async function loadData() {
      const { data } = await supabaseClient
        .from('donations')
        .select('*')
        .eq('id', donationId ?? '')
        .single();
      if (data?.imagePath) {
        const { data: imageData } = supabaseClient.storage.from('imageFile').getPublicUrl(data?.imagePath);
        setImageSrc(imageData?.publicUrl);
      } else {
        setImageSrc('/assets/images/food-placeholder.jpg');
      }
      setStartData(data);
    }
    // Only run query once user is logged in. For RLS
    if (user && donationId) loadData();
  }, [user, supabaseClient, donationId]);

  const handleSubmit = async (
    values: FormikHelper.DonationValues,
    formikHelpers?: FormikHelpers<FormikHelper.DonationValues>
  ) => {
    const dateObj = new Date(values.endDate);
    const localDate = dateObj.toISOString().toLocaleString();

    const submissionValues = {
      title: values?.title,
      description: values?.description,
      amount: values?.amount,
      unit: values?.unit,
      end_date: localDate,
      location: values?.location,
      location_data: values?.locationData,
      category: values?.category,
      subCategory: values?.subCategory,
      imagePath: values?.imagePath,
      quantity: values?.unit === 'quantity' ? values?.quantity : null,
      user_id: user?.id || '0',
    };

    if (!!action) {
      if (!donationId) return;
      const { data } = await supabaseClient.from('donations').update(submissionValues).eq('id', donationId);
      await supabaseClient
        .from('notifications')
        .update({ title: `New donation: ${submissionValues?.title}` })
        .eq('donation_id', donationId);
    } else {
      // The data returned contains the id, due to select() after insert
      const { data } = await supabaseClient.from('donations').insert(submissionValues).select('id').single();
      // Create new donation notification which propagates to all users
      await supabaseClient
        .from('notifications')
        .insert({ donation_id: data?.id, seen: false, title: `New donation: ${submissionValues?.title}` });
    }

    router.push('/donations');
  };

  return (
    <PageWrapper>
      <div className={styles.wrapper}>
        {((!donationId && !startData) || (!!donationId && !!startData)) && (
          <Formik
            onSubmit={handleSubmit}
            initialValues={NewDonation.initialValues(startData, !!action)}
            validationSchema={donationSchema}>
            {({ values }) => (
              <Form className={styles.form}>
                <h3>{!action ? 'Add a' : 'Edit'} donation</h3>
                <TextField name="title" placeholder="Enter title" />
                <TextField name="description" placeholder="Enter description & pickup details" />
                <SelectField name="unit" options={weightOptions} />

                {values?.unit &&
                  (values?.unit === 'quantity' ? (
                    <div className={styles.quantityField}>
                      <NumberField
                        label="weight per item"
                        name="amount"
                        placeholder="Approximate kg per item"
                        unitOverlay="kg"
                      />
                      <NumberField label="quantity" name="quantity" placeholder="Enter Quantity" step={1} />
                    </div>
                  ) : (
                    <NumberField
                      label="weight"
                      name="amount"
                      placeholder="approximattion of food"
                      unitOverlay={values?.unit}
                    />
                  ))}

                <DateField name="endDate" label="Available Till:" />
                <AddressField name="location" placeholder="Pickup location" />
                <SelectField name="category" label="Select Category:" options={categoryOptions} />

                {!!values?.category && (
                  <SelectField
                    name="subCategory"
                    label="Select Subcategory:"
                    options={[
                      { value: '', label: 'Select Sub Category', disabled: true },
                      ...subcategoryOptions[values.category],
                    ]}
                  />
                )}

                <ImageField name="imagePath" label="Upload an image" existingImageSrc={imageSrc} />
                <button type="submit" className={styles.submit}>
                  {!action ? 'Add' : 'Update'}
                </button>
              </Form>
            )}
          </Formik>
        )}
      </div>
    </PageWrapper>
  );
};

NewDonation.initialValues = (startData: Tables.Donations | null, action: boolean): FormikHelper.DonationValues => ({
  title: startData?.title || '',
  description: startData?.description || '',
  amount: startData?.amount || 0.0,
  unit: startData?.unit || '',
  endDate: !!action && startData?.end_date ? new Date(startData?.end_date).toISOString().slice(0, 16) : '',
  location: startData?.location || '',
  locationData: startData?.location_data || null,
  category: startData?.category || '',
  subCategory: startData?.subCategory || '',
  imagePath: startData?.imagePath || '',
  quantity: startData?.quantity || 0,
});

let donationSchema = yup.object({
  title: yup.string().min(2).required('Please enter a title for your donation'),
  description: yup.string(),
  amount: yup
    .number()
    .min(0.1, 'Must be at least 100 grams')
    .required("Please input the amount you're donating")
    .positive(),
  unit: yup.string().required('Please select the unit of measurement'),
  quantity: yup.number().when('unit', {
    is: 'quantity',
    then: (schema) => schema.min(1),
  }),
  endDate: yup
    .date()
    .min(new Date(), 'Date must be today or later')
    .required('Please select the date this will be available till'),
  location: yup.string().required('Please enter a location for donation pickup'),
  locationData: yup.object().required('You must select an address from the dropdown'),
  category: yup.string().required('Please select the category of food you are donating'),
  subCategory: yup.string().required('Please select the sub-category of food you are donating'),
});

export default NewDonation;
