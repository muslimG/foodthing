import React, { useEffect, useState } from 'react';
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react';

import AlarmIcon from '@/components/icons/svg/tabler-alarm.svg';
import BoxIcon from '@/components/icons/svg/tabler-box-seam.svg';
import ConfirmDonationModal from '@/components/modals/ConfirmDonationModal';
import DonationDynamicIcon from '@/components/DonationDynamicIcon';
import EditIcon from '@/components/icons/svg/tabler-edit.svg';
import Image from '@/components/Image';
import Link from 'next/link';
import MapboxMap from '@/components/MapboxMap';
import PageWrapper from '@/components/layout/PageWrapper';
import ReactModal from 'react-modal';
import ScaleLoader from 'react-spinners/ScaleLoader';
import SingleActionModal from '@/components/modals/SingleActionModal';
import TrashIcon from '@/components/icons/svg/tabler-trash.svg';
import WeightIcon from '@/components/icons/svg/tabler-weight.svg';
import cc from 'classcat';
import { getCurrentUserData } from '@/lib/queries';
import styles from './index.module.scss';
import { useRouter } from 'next/router';
import useSupabaseQuery from '@/hooks/useSupabaseQuery';
import useTimeLeft from '@/hooks/useTimeLeft';

const ViewDonation = () => {
  const supabaseClient = useSupabaseClient<Database>();
  const user = useUser();
  const [data, setData] = useState<Tables.Donations | null>(null);
  const [imageSrc, setImageSrc] = useState<string>('/assets/images/food-placeholder.jpg');
  const router = useRouter(); // get next router for query param
  const [imageModal, setImageModal] = useState<boolean>(false);
  const [collectModal, setCollectModal] = useState<boolean>(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const donationId = Array.isArray(router.query.id) ? router.query.id[0] : router.query.id;

  const [userData] = useSupabaseQuery(getCurrentUserData);

  useEffect(() => {
    async function loadData() {
      if (!donationId) return;
      const { data } = await supabaseClient.from('donations').select('*').eq('id', donationId).single();
      if (data?.imagePath) {
        const { data: imageData } = supabaseClient.storage.from('imageFile').getPublicUrl(data?.imagePath);
        imageData?.publicUrl && setImageSrc(imageData.publicUrl);
      }
      setData(data);
    }
    // Only run query once user is logged in. For RLS
    if (user && donationId) loadData();
  }, [user, supabaseClient, donationId]);

  const timeLeft = useTimeLeft(data?.end_date);
  const locationData = data?.location_data as unknown as Mapbox.GeocodeFeature;

  const handleCollect = async () => {
    if (!donationId) return;

    const { error: donationError } = await supabaseClient
      .from('donations')
      .update({
        collector_id: user?.id,
        collect_date: new Date().toISOString().toLocaleString(),
        col_confirm: null,
        don_confirm: null,
      })
      .eq('id', donationId);

    if (!donationError && data) {
      await supabaseClient.from('notifications').insert({
        user_id: data.user_id, // This is the original donor's ID
        title: 'Someone wants to collect your donation',
        donation_id: data.id,
      });
    }
    router.reload();
  };

  const handleDelete = async () => {
    if (!donationId) return;
    const { error } = await supabaseClient.from('donations').delete().eq('id', donationId);
    await supabaseClient.from('notifications').delete().eq('donation_id', donationId);
    !error && router.push('/donations');
  };

  const handleCancel = async () => {
    if (!donationId) return;
    const { data, error } = await supabaseClient
      .from('donations')
      .update({ collector_id: null, col_confirm: null, don_confirm: null })
      .eq('id', donationId);
    !error && router.reload();
  };

  const handleDonConfirmation = async () => {
    if (!donationId) return;
    const submissionValues = {
      don_confirm: true,
      confirmDate: data?.col_confirm ? new Date().toISOString().toLocaleString() : null,
    };

    const { error: updateError } = await supabaseClient.from('donations').update(submissionValues).eq('id', donationId);

    if (!updateError && data) {
      await supabaseClient.from('notifications').insert({
        user_id: data.collector_id, // This is the collectors ID
        title: 'The donator has confirmed your collection',
        donation_id: data.id,
      });
      router.reload();
    }
  };

  return (
    <PageWrapper
      backBtn
      headerRight={
        user?.id == data?.user_id && !data?.confirmDate ? (
          <TrashIcon className={styles.delete} onClick={() => setDeleteModal(true)} />
        ) : undefined
      }>
      <div className={styles.wrapper}>
        {!!data ? (
          <>
            {!!imageSrc && (
              <div className={styles.imgHeader} onClick={() => setImageModal(!imageModal)}>
                <ScaleLoader
                  color="#58ab5b"
                  cssOverride={{ margin: 'auto auto' }}
                  aria-label="Loading Spinner"
                  data-testid="loader"
                  className={styles.imgLoader}
                />
                <ReactModal isOpen={imageModal} overlayClassName={styles.overlay} className={styles.modal}>
                  <Image alt="donation image" src={imageSrc} className={styles.modalImageFormat} />
                </ReactModal>
                <Image alt="donation image" src={imageSrc} className={styles.imageFormat} />
              </div>
            )}
            <DonationDynamicIcon category={data?.category} className={styles.categoryIcon} />
            <div className={styles.textContent}>
              <h2 className={styles.titleText}>{data?.title}</h2>
              <p className={styles.subtitleText}>{data?.category}</p>
              <p className={styles.subtitleText}>{data?.subCategory}</p>
              <div className={styles.pairedData}>
                <div className={styles.metricView}>
                  <WeightIcon />
                  <p>{`${data?.amount} ${!data?.quantity ? data?.unit : 'kg'}`}</p>
                </div>
                {data?.quantity && (
                  <div className={styles.metricView}>
                    <BoxIcon />
                    <p>{data?.quantity} qty</p>
                  </div>
                )}
              </div>
              <div className={styles.pairedData}>
                <div className={styles.metricView}>
                  <AlarmIcon />
                  <p>{timeLeft}</p>
                </div>
              </div>
              {data?.description && (
                <div className={styles.description}>
                  <p className={styles.heading}>Details</p>
                  <p className={styles.content}>{data?.description}</p>
                </div>
              )}
              <div className={styles.location}>
                <p className={styles.heading}>Location:</p>
                <p className={styles.content}>{data?.location}</p>
                <div className={styles.mapWrapper}>
                  {' '}
                  {locationData && (
                    <MapboxMap longitude={locationData?.center?.[0]} latitude={locationData?.center?.[1]} />
                  )}
                </div>
              </div>

              <div className={styles.actions}>
                {user?.id == data?.user_id && (
                  <>
                    <Link className={styles.linkBtn} href={`/donations/new/${data?.id}`}>
                      <button className={styles.collectBtn}>Re-Donate</button>
                    </Link>
                    <Link className={styles.linkBtn} href={`/donations/new/${data?.id}-edit`}>
                      <p>Edit</p>
                      <EditIcon className={styles.editBtn} />
                    </Link>
                  </>
                )}

                {user?.id == data?.user_id && userData?.is_donor && !!data?.collector_id && !!!data?.don_confirm && (
                  <button className={cc([styles.goodBtn, styles.fullBtn])} onClick={handleDonConfirmation}>
                    Confirm collector has collected donation
                  </button>
                )}

                {user?.id != data?.collector_id && user?.id != data?.user_id && !userData?.is_donor && (
                  <button className={cc([styles.goodBtn, styles.fullBtn])} onClick={handleCollect}>
                    Request collection
                  </button>
                )}

                {user?.id == data?.collector_id && !userData?.is_donor && !data?.col_confirm && (
                  <p>Chat with the donor in the chat page to arrange a pickup time.</p>
                )}

                {user?.id == data?.collector_id && !userData?.is_donor && !data?.col_confirm && (
                  <button className={cc([styles.dangerBtn, styles.fullBtn])} onClick={handleCancel}>
                    Cancel collection
                  </button>
                )}

                {user?.id == data?.collector_id && !userData?.is_donor && data?.collector_id && !data?.col_confirm && (
                  <>
                    <button
                      className={cc([styles.goodBtn, styles.fullBtn])}
                      onClick={() => setCollectModal(!collectModal)}>
                      Confirm you have collected donation
                    </button>
                    <ConfirmDonationModal
                      data={data}
                      isOpen={collectModal}
                      donationId={donationId}
                      setIsOpen={setCollectModal}
                    />
                  </>
                )}
              </div>
            </div>
            <SingleActionModal
              isOpen={deleteModal}
              setIsOpen={setDeleteModal}
              title="Are you sure you want to delete this donation?"
              bodyText="You will not be able to restore it once deleted"
              onConfirm={handleDelete}
            />
          </>
        ) : (
          <ScaleLoader
            color="#58ab5b"
            cssOverride={{ margin: 'auto auto' }}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
        )}
      </div>
    </PageWrapper>
  );
};

export default ViewDonation;
