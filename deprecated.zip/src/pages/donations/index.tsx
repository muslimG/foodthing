import { Form, Formik, FormikHelpers } from 'formik';
import React, { useEffect, useState } from 'react';
import { getCollectableDonations, getCurrentUserData } from '@/lib/queries';
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react';

import Donation from '@/components/Donation';
import Link from 'next/link';
import PageWrapper from '@/components/layout/PageWrapper';
import PlusIcon from '@/components/icons/svg/tabler-cirlce-plus.svg';
import ScaleLoader from 'react-spinners/ScaleLoader';
import TextField from '@/components/fields/TextField';
import styles from './index.module.scss';
import useSupabaseQuery from '@/hooks/useSupabaseQuery';

const Donations = () => {
  const supabaseClient = useSupabaseClient<Database>();
  const user = useUser();
  const [data, setData] = useState<Tables.Donations[] | null>(null);
  const [userData] = useSupabaseQuery(getCurrentUserData);

  const handleSearch = async (values: FormikHelper.Search, formikHelpers?: FormikHelpers<FormikHelper.Search>) => {
    if (!user) return;

    // will make this into a clear button later
    if (!values.search) {
      const { data } = await getCollectableDonations(supabaseClient, user);
      setData(data ?? []);
      return;
    }

    setData(null); // so it shows loader
    const { data } = await supabaseClient
      .from('donations')
      .select()
      .gte('end_date', new Date().toISOString().toLocaleString())
      .is('collector_id', null)
      .order('id', { ascending: false })
      .ilike('title', `%${values?.search}%`);
    setData(data);
  };

  useEffect(() => {
    async function loadData() {
      const { data } = await getCollectableDonations(supabaseClient, user);
      setData(data ?? []);
    }

    // Only run query once user is logged in. For RLS
    if (user) loadData();
  }, [user, supabaseClient]);

  return (
    <PageWrapper
      headerRight={
        !!userData?.is_donor ? (
          <Link href="/donations/new">
            <PlusIcon className={styles.plus} />
          </Link>
        ) : undefined
      }>
      <div className={styles.wrapper}>
        <Link href="/map" className={styles.mapBtn}>
          <button type="button">View Map</button>
        </Link>
        <Formik onSubmit={handleSearch} initialValues={{ search: '' }}>
          {({}) => (
            <Form>
              <div className={styles.searchWrapper}>
                <TextField name="search" placeholder="Search" submitOnEnter />
                <button type="submit">search</button>
              </div>
            </Form>
          )}
        </Formik>
        {!!data ? (
          !!data?.length ? (
            data.map((donation) => (
              <Link
                className={styles.cleanLink}
                key={`${donation.title}-${donation.id}`}
                href={`donations/view/${donation.id}`}>
                <Donation
                  title={donation?.title}
                  weight={donation?.amount}
                  unit={donation?.unit}
                  quantity={donation?.quantity}
                  duration={donation?.end_date}
                  locationData={donation?.location_data}
                  category={donation?.category}
                  subCategory={donation?.subCategory}
                />
              </Link>
            ))
          ) : (
            <p className={styles.noDonations}>No donations are available</p>
          )
        ) : (
          <ScaleLoader
            color="#58ab5b"
            cssOverride={{ margin: 'auto auto' }}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
        )}
      </div>
    </PageWrapper>
  );
};

export default Donations;
