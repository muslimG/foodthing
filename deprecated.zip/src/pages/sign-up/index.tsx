import Link from 'next/link';
import React from 'react';
import SignUpForm from '@/components/forms/SignUpForm';
import styles from './index.module.scss';

interface Props {}

const SignUp = ({}: Props) => {
  return (
    <div className={styles.wrapper}>
      <div className={styles.center}>
        <h1 className={styles.heading}>Create Account</h1>
        <SignUpForm />
        <Link href="/" className={styles.altLink}>
          login with existing account?
        </Link>
      </div>
    </div>
  );
};

export default SignUp;
