import React, { useCallback, useEffect, useState } from 'react';
import { calculateLngLatDistance, convertToGeocodeFeature, formatDateDifferenceShort } from '@/lib/utils';
import { subscribeUserToPush, unsubscribeUserFromPush } from '@/lib/swHelpers';
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react';

import Link from 'next/link';
import PageWrapper from '@/components/layout/PageWrapper';
import ScaleLoader from 'react-spinners/ScaleLoader';
import SparkleIcon from '@/components/icons/svg/tabler-sparkle.svg';
import Switch from 'react-switch';
import { getCurrentUserData } from '@/lib/queries';
import styles from './index.module.scss';
import { uniq } from 'lodash';
import useNotificationSW from '@/hooks/useNotificationSW';
import useSupabaseQuery from '@/hooks/useSupabaseQuery';

const Notifications = () => {
  const supabaseClient = useSupabaseClient<Database>();
  const user = useUser();
  const [notifications, setNotifications] = useState<Tables.Notifications[] | null>(null);
  const [donations, setDonations] = useState<Partial<Tables.Donations>[] | null>(null);
  const [browserEnabled, setBrowserEnabled] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [subscription, setSubscription] = useState<PushSubscription | null>(null);
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);

  const [userData] = useSupabaseQuery(getCurrentUserData);

  // Function to fetch notifications for the current user
  const fetchNotifications = useCallback(async () => {
    if (!user) return;

    const { data, error } = await supabaseClient
      .from('notifications')
      .select('*')
      .or(`user_id.eq.${user.id}, user_id.is.${null}`)
      .order('created_at', { ascending: false });

    const donationIds = data?.map((notification) => notification?.donation_id);
    const uniqDonationIds = uniq(donationIds);
    const eqDonationIds = uniqDonationIds?.map((donationId) => `id.eq.${donationId}`);

    const { data: donationData } = await supabaseClient
      .from('donations')
      .select(`title, location_data, id, user_id`)
      .or(eqDonationIds?.join(', '))
      .order('created_at', { ascending: false });

    setNotifications(data);
    setDonations(donationData);
  }, [user, supabaseClient]);

  // Function to check if the user is subscribed to push notifications
  const checkSubscription = useCallback(async () => {
    if (!user || !subscription) return;

    const { data, error } = await supabaseClient
      .from('push_subscriptions')
      .select('id')
      .eq('user_id', user.id)
      .eq('subscription', JSON.stringify(subscription) || '');

    if (error) {
      console.error('Error checking subscription:', error);
      return;
    }

    setIsSubscribed(data && data.length > 0);
  }, [user, subscription, supabaseClient]);

  // Function to handle the switch for enabling/disabling notifications
  const handleSwitchChange = async () => {
    isSubscribed
      ? await unsubscribeUserFromPush(subscription, setSubscription, setIsSubscribed, supabaseClient, user)
      : await subscribeUserToPush(
          registration,
          setSubscription,
          setIsSubscribed,
          setBrowserEnabled,
          supabaseClient,
          user
        );
  };

  useNotificationSW(setSubscription, setIsSubscribed, setRegistration);

  useEffect(() => {
    if (!user || !supabaseClient) return;

    // Fetch the user's notifications and check their push notification subscription status
    fetchNotifications();
    checkSubscription();
  }, [user, supabaseClient, fetchNotifications, checkSubscription]);

  const userLngLat = convertToGeocodeFeature(userData?.address_data)?.geometry?.coordinates;

  return (
    <PageWrapper>
      <div className={styles.wrapper}>
        {registration && (
          <div className={styles.switchContainer}>
            <p>Push notifications</p>
            <Switch checked={isSubscribed} onChange={handleSwitchChange} />
          </div>
        )}
        {notifications ? (
          notifications?.length ? (
            notifications.map((notification) => {
              const donation = donations?.find((don) => don?.id === notification.donation_id);
              if (!!notification?.title?.match(/new donation/gi) && donation?.user_id === userData?.id) return null;

              const donationLngLat = convertToGeocodeFeature(donation?.location_data)?.geometry?.coordinates;
              return (
                <Link
                  key={notification.id}
                  href={`/donations/view/${donation?.id}`}
                  className={styles.cleanLink}
                  passHref>
                  <SparkleIcon />
                  <div>
                    <span>
                      {notification.title}{' '}
                      <span className={styles.timestamp}>{formatDateDifferenceShort(notification?.created_at)}</span>
                    </span>
                    {userLngLat && donationLngLat && (
                      <span>{calculateLngLatDistance(userLngLat, donationLngLat).toFixed(2)} Kms</span>
                    )}
                  </div>
                </Link>
              );
            })
          ) : (
            <div>
              <p>You are all caught up</p>
            </div>
          )
        ) : (
          <ScaleLoader
            color="#58ab5b"
            cssOverride={{ margin: 'auto auto' }}
            aria-label="Loading Spinner"
            data-testid="loader"
          />
        )}
      </div>
    </PageWrapper>
  );
};

export default Notifications;
