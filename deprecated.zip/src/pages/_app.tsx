import '@/styles/globals.scss';
import 'mapbox-gl/dist/mapbox-gl.css';

import type { AppProps } from 'next/app';
import Head from 'next/head';
import Modal from 'react-modal';
import { SessionContextProvider } from '@supabase/auth-helpers-react';
import { createPagesBrowserClient } from '@supabase/auth-helpers-nextjs';
import { useState } from 'react';
import useWindowHeight from '@/hooks/useWindowHeight';

Modal.setAppElement('#__next');

function App({ Component, pageProps }: AppProps) {
  // Create a new supabase browser client on every first render.
  const [supabaseClient] = useState(() => createPagesBrowserClient());

  // sets window height dynamically to css variable
  useWindowHeight();

  return (
    <div className="app">
      <Head>
        <meta
          name="viewport"
          content="minimum-scale=1, initial-scale=1, width=device-width, shrink-to-fit=no, user-scalable=no, viewport-fit=cover"
        />
        <title>ReFood</title>
      </Head>
      <SessionContextProvider supabaseClient={supabaseClient} initialSession={pageProps.initialSession}>
        <Component {...pageProps} />
      </SessionContextProvider>
    </div>
  );
}

export default App;
