import { NextApiHandler } from 'next';
import { createPagesServerClient } from '@supabase/auth-helpers-nextjs';

// Private key do not expose client side or share this key on insecure platforms
const authKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

/**
 * Specialised API route that retrieves the current supabase user
 * using their cookies/jwt. If a user is present then it will use their
 * id with the admin supabase client to delete their profile.
 * * Note this will cause any cascade on delete foreign key links to be triggered
 *
 * @param req - The incoming request
 * @param res - The response sent back from the API
 * @returns the response
 */
const handler: NextApiHandler = async (req, res) => {
  const supabaseSafeClient = createPagesServerClient({ req, res });
  const userSessionRes = await supabaseSafeClient.auth.getUser();
  const userId = userSessionRes?.data?.user?.id;

  if (userId && typeof userId === 'string') {
    const supabase = createPagesServerClient({ req, res }, { supabaseKey: authKey });

    const deleteRes = await supabase.auth.admin.deleteUser(userId);
    const { data, error } = deleteRes;

    if (error) {
      res.status(error?.status || 501).json({ success: false, error });
      return;
    }

    res.status(200).json({ success: true });
    return;
  }

  res.status(403).json({ success: false, error: 'Bad Request' });
};

export default handler;
