import { NextApiHandler } from 'next';

const mockAbn = {
  Abn: '12341234420',
  AbnStatus: 'Active',
  AbnStatusEffectiveFrom: '2023-08-23',
  Acn: '',
  AddressDate: '2023-08-23',
  AddressPostcode: '6000',
  AddressState: 'WA',
  BusinessName: [],
  EntityName: 'FISH & CO HOLDINGS PTY',
  EntityTypeCode: 'PTY',
  EntityTypeName: 'Proprietary company',
  Gst: null,
  Message: '',
};

// Prevent randoms from using the endpoint for abn validation
const allowedDomains = [
  'http://localhost:3000',
  'https://refood-staging.life-of-dan.dev',
  'https://refood.life-of-dan.dev',
];

const handler: NextApiHandler = async (req, res) => {
  const { method, body } = req;
  const isAllowed = allowedDomains?.includes(req.headers?.origin || '') || false;

  if (process.env.NODE_ENV === 'development') {
    res.status(200).json({ success: 'true', abnData: mockAbn });
    return;
  }

  if (method !== 'POST' || !isAllowed) {
    res.status(401).json({ error: 'bad request' });
    return;
  }

  const guid = process.env.ABN_GUID || '';
  const abn = body?.abn || '';

  const url = `https://abr.business.gov.au/json/AbnDetails.aspx?abn=${abn}&guid=${guid}`;

  try {
    const abnResText = await fetch(url)?.then(async (res) => await res.text());
    const abnToJsonStr = abnResText?.replace('callback(', '')?.replace('})', '}');
    const abnAsJson = await JSON.parse(abnToJsonStr);

    if (abnAsJson?.AbnStatus === 'Active') {
      res.status(200).json({ success: true, abnData: abnAsJson });
      return;
    }

    res.status(401).json({ error: 'Invalid or inactive abn' });
  } catch (e) {
    res.status(401).json({ error: 'bad request' });
  }
};

export default handler;
