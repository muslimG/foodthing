import { NextApiHandler } from 'next';
import { createPagesServerClient } from '@supabase/auth-helpers-nextjs';
import webPush from 'web-push';

webPush.setVapidDetails(
  `mailto:${process.env.WEB_PUSH_EMAIL}`,
  process.env.NEXT_PUBLIC_WEB_PUSH_PUBLIC_KEY || '',
  process.env.WEB_PUSH_PRIVATE_KEY || ''
);

const authKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const Notification: NextApiHandler = async (req, res) => {
  if (req.method == 'POST') {
    const webhookBody: InsertPayload<Tables.Notifications> = req.body;
    const { title, user_id, donation_id } = webhookBody.record;
    if (!title) return;

    const supabase = createPagesServerClient<Database>({ req, res }, { supabaseKey: authKey });
    let donationData: Tables.Donations | null = null;

    if (donation_id) {
      const { data, error } = await supabase.from('donations').select('*').eq('id', donation_id).single();
      if (!data || error) {
        console.error(error);
        res.status(parseInt(error.code));
        res.end();
        return;
      }
      donationData = data;
    }

    if (user_id) {
      const { data, error } = await supabase.from('push_subscriptions').select('*').eq('user_id', user_id).single();

      if (!data || error || !data.subscription) {
        console.error(error);
        res.status(parseInt(error?.code || '500'));
        res.end();
        return;
      }

      try {
        const subscription = data.subscription as unknown as webPush.PushSubscription;

        const webPushRes = await webPush.sendNotification(
          subscription,
          JSON.stringify({ title, message: 'Refood notification' })
        );
        res.writeHead(webPushRes.statusCode, webPushRes.headers).end(webPushRes.body);
        res.end();
        return;
      } catch (e: any) {
        if ('statusCode' in e) {
          res.writeHead(e.statusCode, e.headers).end(e.body);
        } else {
          res.statusCode = 500;
        }

        res.end();
        return;
      }
    } else {
      const { data, error } = await supabase
        .from('push_subscriptions')
        .select('*')
        .eq('user_id', '88aab3d3-0b61-445f-b75d-0660885e971e')
        .single();

      if (!data || error || !data.subscription) {
        console.error(error);
        res.status(parseInt(error?.code || '500'));
        res.end();
        return;
      }

      try {
        const subscription = data.subscription as unknown as webPush.PushSubscription;

        const webPushRes = await webPush.sendNotification(
          subscription,
          JSON.stringify({ title, message: 'Refood notification' })
        );
        res.writeHead(webPushRes.statusCode, webPushRes.headers).end(webPushRes.body);
        res.end();
        return;
      } catch (e: any) {
        if ('statusCode' in e) {
          res.writeHead(e.statusCode, e.headers).end(e.body);
        } else {
          res.statusCode = 500;
        }

        res.end();
        return;
      }
    }
  } else {
    res.statusCode = 405;
    res.end();
  }
};

export default Notification;
