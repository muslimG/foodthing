import { NextApiHandler } from 'next';
import { createPagesServerClient } from '@supabase/auth-helpers-nextjs';
import webPush from 'web-push';

webPush.setVapidDetails(
  `mailto:${process.env.WEB_PUSH_EMAIL}`,
  process.env.NEXT_PUBLIC_WEB_PUSH_PUBLIC_KEY || '',
  process.env.WEB_PUSH_PRIVATE_KEY || ''
);

const authKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const ChatPushNotification: NextApiHandler = async (req, res) => {
  if (req.method == 'POST') {
    // Get payload from chat insert
    const webhookBody: InsertPayload<Tables.ChatMessages> = req.body;
    const { sender_id, chat_text, donation_id } = webhookBody.record;

    // Make sure all required fields are set
    if (!sender_id || !chat_text || !donation_id) {
      console.error('Error with record', webhookBody.record);
      res.status(500);
      res.end();
      return;
    }

    // Create admin client to be able to use supabase queries without user
    const supabase = createPagesServerClient<Database>({ req, res }, { supabaseKey: authKey });

    // Get donation data relevant to chat
    const { data: donation, error } = await supabase
      .from('donations')
      .select('title, collector_id, user_id')
      .eq('id', donation_id)
      .single();

    if (!donation || error) {
      console.error(error);
      res.status(500);
      res.end();
      return;
    }

    // Determine receiver of chat message from donation
    const receiver_id = sender_id === donation?.user_id ? donation?.collector_id : donation?.user_id;

    if (receiver_id) {
      // Get receiver push notification entry if they have it
      const { data: receiver, error: receiverErr } = await supabase
        .from('push_subscriptions')
        .select('*')
        .eq('user_id', receiver_id)
        .single();

      // Get sender first name for push message
      const { data: sender, error: senderErr } = await supabase
        .from('user_data')
        .select('first_name')
        .eq('id', sender_id)
        .single();

      // Handle any errors or missing data
      if (!receiver || receiverErr || senderErr || !sender || !receiver.subscription) {
        console.error(receiverErr ?? senderErr ?? 'no data');
        res.status(500);
        res.end();
        return;
      }

      // Typecast subscription field since we know it exists
      const subscription = receiver.subscription as unknown as webPush.PushSubscription;

      // Attempt to send push
      try {
        const webPushRes = await webPush.sendNotification(
          subscription,
          JSON.stringify({ title: `${donation.title} - ${sender?.first_name}`, message: chat_text })
        );
        res.writeHead(webPushRes.statusCode, webPushRes.headers).end(webPushRes.body);
        res.end();
        return;
      } catch (e: any) {
        if ('statusCode' in e) {
          res.writeHead(e.statusCode, e.headers).end(e.body);
        } else {
          res.statusCode = 500;
        }

        res.end();
        return;
      }
    }
  } else {
    res.statusCode = 405;
    res.end();
  }
};

export default ChatPushNotification;
