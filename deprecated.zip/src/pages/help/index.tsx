import React, { useState } from 'react';

import Image from '@/components/Image';
import PageWrapper from '@/components/layout/PageWrapper';
import { divide } from 'lodash';
import { getCurrentUserData } from '@/lib/queries';
import styles from './index.module.scss';
import useSupabaseQuery from '@/hooks/useSupabaseQuery';

const Help = () => {
  let content;

  const [userData] = useSupabaseQuery(getCurrentUserData);
  if (userData?.is_donor) {
    // Donor content
    content = (
      <>
        <h1 className={styles.subintro}>For Donors</h1>
        <div className={styles.helpText}>
          <h1 className={styles.topicTitle}>Donations Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/donations.png" alt="donations" />
              <p className={styles.topicDesc}>
                On the bottom bar, tap this icon to access the donations page. This page lists all donations posted in
                the app.{' '}
              </p>
            </div>

            <div className={styles.topicLR}>
              <p className={styles.topicDesc}>In the top right corner, tap the plus icon to add a new donation.</p>
              <Image className={styles.topicImageLR} src="/assets/images/add.png" alt="add" />
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/view-map.png" alt="view map" />
              <p className={styles.topicDesc}>
                Tap this View Map button at the top of the donation page to view an interactive map of all available
                donations.
              </p>
            </div>
            <div className={styles.topicLR}>
              <p className={styles.topicDesc}>Tap a pin on the map to bring up more donation details and options.</p>
              <Image className={styles.topicImageRL} src="/assets/images/map.png" alt="map" />
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/search.png" alt="search" />
              <p className={styles.topicDesc}>Use the search bar to filter donations by title, category or location.</p>
            </div>
          </div>

          <h1 className={styles.topicTitle}>Profile Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/profile.png" alt="profile" />
              <p className={styles.topicDesc}>On the bottom bar, tap this icon to access the profile page.</p>
            </div>
            <div className={styles.topicLR}>
              <p className={styles.topicDesc}>On the top right corner, tap this icon to logout.</p>
              <Image className={styles.topicImageLR} src="/assets/images/logout.png" alt="logout" />
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/bar.png" alt="donation bar" />
            </div>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/delete.png" alt="delete" />
              <p className={styles.topicDesc}>
                Under the &apos;Pending&apos; tab are all your donations pending collection. Under the
                &apos;Completed&apos; tab are your donations that have been collected. Tapping on donations will allow
                you to &apos;Re-Donate&apos;, &apos;Edit&apos; or delete your donation as appropriate.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/options.png" alt="options" />
              <p className={styles.topicDesc}>
                If someone has collected your donation, you can also &apos;Confirm collector has collected
                donation&apos; here.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/settings.png" alt="settings" />
              <p className={styles.topicDesc}>
                In the profile page, you can also update your details in &apos;Settings&apos;.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/reporting2.png" alt="reporting" />
              <p className={styles.topicDesc}>
                Tapping the reporting suite button will bring you to visualisations and reports of your collected
                donations.
              </p>
            </div>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageBig} src="/assets/images/pie.png" alt="pie" />
              <p className={styles.topicDesc}>
                Here, you can show pie or bar charts to visualise your collected donations.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/categories.png" alt="categories" />
              <p className={styles.topicDesc}>In this category dropdown, you can filter the models by category.</p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/donorCSV.png" alt="donorCSV" />
              <p className={styles.topicDesc}>
                You can download CSV reports on your donations with this &apos;Donations&apos; button.
              </p>
            </div>
          </div>

          <h1 className={styles.topicTitle}>Updates Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/updates.png" alt="updates" />
              <p className={styles.topicDesc}>
                On the bottom bar, tap this icon to access the updates or notification page. Here you can access
                notifications on new collection requests and collection confirmations.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/notifications.png" alt="notifications" />
              <p>
                On accessing this page for the first time and turning on this switch, you will be asked to
                &apos;Allow&apos; device notifications. This popup request will only appear once. In choosing
                &apos;Allow&apos;, ReFood notifications will appear in your device as push notifications to inform you
                of new donations and chat messages.
              </p>
            </div>
          </div>

          <h1 className={styles.topicTitle}>Chat Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/chat.png" alt="chat" />
              <p className={styles.topicDesc}>
                On the bottom bar, tap this icon to access the chat page. Here, you can message collectors for donations
                they have accepted. Chat for any donation clarifications and collection arrangement.
              </p>
            </div>
          </div>
        </div>
      </>
    );
  } else {
    // Collector content
    content = (
      <>
        <h1 className={styles.subintro}>For Collectors</h1>
        <div className={styles.helpText}>
          <h1 className={styles.topicTitle}>Donations Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/donations.png" alt="donations" />
              <p className={styles.topicDesc}>
                On the bottom bar, tap this icon to access the donations page. This page lists all donations available
                to collect.{' '}
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/view-map.png" alt="view map" />
              <p className={styles.topicDesc}>
                Tap this View Map button at the top of the donation page to view an interactive map of all available
                donations.
              </p>
            </div>
            <div className={styles.topicLR}>
              <p className={styles.topicDesc}>Tap a pin on the map to bring up more donation details and options.</p>
              <Image className={styles.topicImageRL} src="/assets/images/map.png" alt="map" />
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/search.png" alt="search" />
              <p className={styles.topicDesc}>Use the search bar to filter donations by title, category or location.</p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/collect.png" alt="collect" />
              <p className={styles.topicDesc}>
                Once you click on a donation in the list, if you would like to collect it, click the &apos;Request
                Collection&apos; button at the bottom. This will add it to your profile page.
              </p>
            </div>
          </div>

          <h1 className={styles.topicTitle}>Profile Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/profile.png" alt="profile" />
              <p className={styles.topicDesc}>On the bottom bar, tap this icon to access the profile page. </p>
            </div>
            <div className={styles.topicLR}>
              <p className={styles.topicDesc}>On the top right corner, tap this icon to logout.</p>
              <Image className={styles.topicImageLR} src="/assets/images/logout.png" alt="logout" />
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/collections.png" alt="collections" />
              <p className={styles.topicDesc}>
                Under the &apos;Pending&apos; donations you have clicked &apos;Request Collection&apos; on. Tapping on
                any of these will allow you to cancel a collection, or to confirm that you have collected it. In the
                &apos;Completed&apos; tab are all donations you have confirmed collection on:
              </p>
              <Image className={styles.topicImageUD} src="/assets/images/cancel-confirm.png" alt="cancel and confirm" />
              <p className={styles.topicDesc}>
                On confirming your collection, you can change the quantity or weight collected if it differed from your
                expectations:
              </p>
              <Image className={styles.topicImageUD} src="/assets/images/confirm.png" alt="confirm" />
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/settings.png" alt="settings" />
              <p className={styles.topicDesc}>
                In the profile page, you can also update your details in &apos;Settings&apos;.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/reporting.png" alt="reporting" />
              <p className={styles.topicDesc}>
                Tapping the report suite button will bring you to visualisations and reports of your collected
                donations.
              </p>
            </div>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageBig} src="/assets/images/pie.png" alt="pie" />
              <p className={styles.topicDesc}>Here, you can show pie or bar charts to visualise your collections.</p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/categories.png" alt="categories" />
              <p className={styles.topicDesc}>
                In this category dropdown, you can filter the models by category collected.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/csv.png" alt="csv" />
              <p className={styles.topicDesc}>
                You can download CSV reports on your collections with this &apos;Collections&apos; button.
              </p>
            </div>
          </div>

          <h1 className={styles.topicTitle}>Updates Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/updates.png" alt="updates" />
              <p className={styles.topicDesc}>
                On the bottom bar, tap this icon to access the updates or notification page. Here you can access
                notifications on new donations and confirmation messages.
              </p>
            </div>
            <div className={styles.topicUD}>
              <Image className={styles.topicImageUD} src="/assets/images/notifications.png" alt="notifications" />
              <p>
                On accessing this page for the first time and turning on this switch, you will be asked to
                &apos;Allow&apos; device notifications. This popup request will only appear once. In choosing
                &apos;Allow&apos;, ReFood notifications will appear in your device as push notifications to inform you
                of new donations and chat messages.
              </p>
            </div>
          </div>

          <h1 className={styles.topicTitle}>Chat Page</h1>
          <div className={styles.topicContainer}>
            <div className={styles.topicLR}>
              <Image className={styles.topicImageLR} src="/assets/images/chat.png" alt="chat" />
              <p className={styles.topicDesc}>
                On the bottom bar, tap this icon to access the chat page. Here, you can message donors for donations you
                have tapped &apos;Collect&apos;. Chat for any donation clarifications and collection arrangement.
              </p>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <PageWrapper backBtn>
      <div className={styles.wrapper}>
        <h1 className={styles.intro}>How to use ReFood</h1>
        <Image className={styles.mainLogoFormat} src="/assets/images/logo.png" alt="logo" />
        {content}
      </div>
    </PageWrapper>
  );
};

export default Help;
