import React, { useMemo, useState } from 'react';
import { getCollectableDonations, getCurrentUserData } from '@/lib/queries';

import MapboxMap from '@/components/MapboxMap';
import PageWrapper from '@/components/layout/PageWrapper';
import { convertToGeocodeFeature } from '@/lib/utils';
import styles from './index.module.scss';
import useSupabaseQuery from '@/hooks/useSupabaseQuery';

const MapPage = () => {
  const [userData] = useSupabaseQuery(getCurrentUserData);
  const [donationData] = useSupabaseQuery(getCollectableDonations);
  const addressData = userData?.address_data as unknown as Mapbox.GeocodeFeature;
  const [donationMarkers, setDoantionMarkers] = useState<Mapbox.Marker[]>([]);

  useMemo(() => {
    setDoantionMarkers(
      donationData
        ?.filter((maybeLocation) => !!maybeLocation?.location_data)
        ?.map((validDonation) => ({
          id: validDonation?.id,
          title: validDonation?.title,
          location: validDonation?.location,
          lng: convertToGeocodeFeature(validDonation?.location_data)?.geometry?.coordinates?.[0],
          lat: convertToGeocodeFeature(validDonation?.location_data)?.geometry?.coordinates?.[1],
        })) ?? []
    );
  }, [donationData]);

  return (
    <PageWrapper backBtn>
      <div className={styles.wrapper}>
        {userData && !!addressData && donationMarkers?.length && (
          <MapboxMap
            initialZoom={10}
            markers={donationMarkers}
            longitude={addressData?.center?.[0]}
            latitude={addressData?.center?.[1]}
          />
        )}
      </div>
    </PageWrapper>
  );
};

export default MapPage;
