import ForgotPasswordForm from '@/components/forms/ForgotPasswordForm';
import Image from '@/components/Image';
import Link from 'next/link';
import React from 'react';
import ResetPasswordForm from '@/components/forms/ResetPasswordForm';
import styles from './index.module.scss';
import { useRouter } from 'next/router';

interface Props {}

const ForgotPassword = ({}: Props) => {
  const router = useRouter();
  const resetCode = Array.isArray(router?.query?.code) ? router?.query?.code[0] : router?.query?.code;

  return (
    <div className={styles.wrapper}>
      <div className={styles.center}>
        <Image src="/icons/android-chrome-512x512.png" alt="logo" className={styles.logo} />
        <h1 className={styles.heading}>ReFood</h1>
        {resetCode ? <ResetPasswordForm code={resetCode} /> : <ForgotPasswordForm />}
      </div>
      <Link href="/" className={styles.forgotPassword}>
        login with existing account?
      </Link>
    </div>
  );
};

export default ForgotPassword;
