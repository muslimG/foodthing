import React, { useState } from 'react';

import EasterEgg from '@/components/EasterEgg';
import HelpIcon from '@/components/icons/svg/tabler-help.svg';
import Image from '@/components/Image';
import Link from 'next/link';
import Modal from 'react-modal';
import PageWrapper from '@/components/layout/PageWrapper';
import TermsAndConditions from '@/components/forms/ConsentForm';
import styles from './index.module.scss';

const Home = () => {
  const [clickCount, setClickCount] = useState<number>(0);
  const [termsOpen, setTermsOpen] = useState(false);

  return (
    <PageWrapper
      headerRight={
        <Link href="/help" className={styles.help}>
          <HelpIcon />
        </Link>
      }>
      {clickCount >= 3 ? (
        <div className={styles.easter}>
          <button className={styles.stopEasterEgg} onClick={() => setClickCount(0)}>
            Reset
          </button>
          <EasterEgg />
        </div>
      ) : (
        <div className={styles.wrapper}>
          <h1 className={styles.intro}>Welcome To ReFood</h1>
          <Image
            className={styles.mainLogoFormat}
            src="/assets/images/logo.png"
            alt="logo"
            onClick={() => setClickCount(clickCount + 1)}
          />
          <div className={styles.homeText}>
            <h1>Who We Are</h1>
            <p>
              <span className={styles.highlightedBox}>
                ReFood is a movement towards a more sustainable and equitable food system...
              </span>
            </p>
            <p>
              Our mission is to bridge the gap between food excess and food scarcity. The mobile ReFood app is a
              platform to empower food businesses who are willing and able to provide excess and fit-for-consumption
              food to make a positive impact. By connecting them directly with local not-for-profit organizations
              dedicated to providing food relief, we can create positive change together.
            </p>
            <p>
              <span className={styles.highlightedBox}>Driven by passion and backed by research...</span>
            </p>
            <p>
              The ReFood Group has tirelessly worked to perfect the ReFood mobile app. Through testing and dedication,
              we have successfully created a Food Sharing Network that optimizes food distribution, reduces waste, and
              supports vulnerable communities.
            </p>
            <h1>Our Goal</h1>
            <p>
              <span className={styles.highlightedBox}>To be a driving force in reducing food waste...</span>
            </p>
            <p>
              By connecting businesses with surplus food to those who can benefit from it the most. ReFood seeks to
              empower food businesses to contribute to the well-being of their communities by redistributing surplus,
              building a stronger and more resilient food system where edible food is no longer wasted.
            </p>
            <h1>How To Use</h1>
            <p>Our user-friendly mobile app brings the power of change to your fingertips.</p>
            <ul>
              <li>
                <p>Do you have excess, perfectly good food that might otherwise go to waste? - Become a Donor</p>
                With ReFood, you can easily post your surplus items on our app, so that community organizations can see
                and accept your donations. Head over to the donations page, tap the plus sign, and add your donation!
                You can also generate a report of your activity to see how much you have donated and where your
                donations have gone.
              </li>
              <li>
                <p>Are you dedicated to fighting food insecurity in your community? - Become a collector</p>
                ReFood connects you with local businesses offering surplus food. Browse listings, claim donations, and
                collect. Head to the donations page and tap on a listing to bring up more information and ways to
                connect with the donor for collection.
              </li>
            </ul>
            <h1>Join Us</h1>
            <p>
              By joining ReFood, you&apos;re not only reducing food waste but also making a real impact on the lives of
              those who need it most.
            </p>
            <p>
              <span className={styles.highlightedBox}>
                Join us in reshaping the food landscape and building a better future, one plate at a time.
              </span>
            </p>
            <h1>Contact Us</h1>
            <p>
              Have questions or feedback? We&apos;d love to hear from you. Please feel free to reach out to us at{' '}
              <a href="mailto:refood@ecu.edu.au" className={styles.emailAddress}>
                refood@ecu.edu.au
              </a>{' '}
              for any inquiries or suggestions. Your input is invaluable in helping us create a more sustainable and
              equitable food system.
            </p>
            <h1>Important Information</h1>
            <p>
              <span className={styles.termsText} onClick={() => setTermsOpen(true)}>
                Terms and conditions
              </span>
              <Modal
                isOpen={termsOpen}
                onRequestClose={() => setTermsOpen(false)}
                overlayClassName={styles.overlay}
                className={styles.modal}>
                <TermsAndConditions setTermsOpen={setTermsOpen} />
              </Modal>
            </p>
            <div className={styles.textblock}>
              <Link href="/privacy">Privacy Policy</Link>
            </div>
          </div>
        </div>
      )}
    </PageWrapper>
  );
};

export default Home;
