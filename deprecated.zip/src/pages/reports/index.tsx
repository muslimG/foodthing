import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, Tooltip, XAxis, YAxis } from 'recharts';
import React, { useEffect, useState } from 'react';
import { convertToKilograms, formatDate } from '@/lib/utils';
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react';

import ChartTypes from 'recharts/types';
import Link from 'next/link';
import PageWrapper from '@/components/layout/PageWrapper';
import { getCurrentUserData } from '@/lib/queries';
import { saveAs } from 'file-saver'; // A library to save files
import { schemeCategory10 } from 'd3-scale-chromatic'; // Import color scheme
import styles from './index.module.scss';
import useSupabaseQuery from '@/hooks/useSupabaseQuery';

const Reports = () => {
  const supabaseClient = useSupabaseClient<Database>();
  const user = useUser();
  const [data, setData] = useState<Tables.Donations[] | null>(null);
  const [categories, setCategories] = useState<{ name: string; weight: number }[]>([]);
  const [subcategories, setSubcategories] = useState<{ name: string; weight: number }[]>([]);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [chartType, setChartType] = useState<'pie' | 'bar'>('pie'); // Initial chart type is 'pie'
  const [activeBarIndex, setActiveBarIndex] = useState<number | null>(null);

  const [userData] = useSupabaseQuery(getCurrentUserData);

  useEffect(() => {
    async function loadData() {
      if (!user?.id) return;
      const categoryFilter = selectedCategory ? { category: selectedCategory } : {};
      const queryEq = userData?.is_donor ? 'user_id' : 'collector_id';

      const { data } = await supabaseClient
        .from('donations')
        .select()
        .eq(queryEq, user.id)
        .eq('col_confirm', true)
        .eq('don_confirm', true)
        .match(categoryFilter);
      setData(data);

      setCategories([]); // reset categories on each fetch
      setSubcategories([]); // reset subcategories on each fetch

      // Initialize categories and subcategories as objects with names as keys and total weights as values
      const categoryWeights: { [name: string]: number } = {};
      const subcategoryWeights: { [name: string]: number } = {};

      // Loops over each donation, checks whether it's added to categories or subcategories
      data?.forEach((donation) => {
        if (donation?.category && donation?.amount) {
          const weight_kgs = convertToKilograms(donation.amount, donation.unit, donation.quantity);

          if (!categoryWeights[donation.category]) {
            categoryWeights[donation.category] = 0;
          }
          categoryWeights[donation.category] += weight_kgs;

          if (donation.subCategory) {
            if (!subcategoryWeights[donation.subCategory]) {
              subcategoryWeights[donation.subCategory] = 0;
            }
            subcategoryWeights[donation.subCategory] += weight_kgs;
          }
        }
      });

      // Convert the categoryWeights object into an array of category objects
      const tempCategories = Object.keys(categoryWeights).map((category) => ({
        name: category,
        weight: categoryWeights[category],
      }));

      // Convert the subcategoryWeights object into an array of subcategory objects
      const tempSubcategories = Object.keys(subcategoryWeights).map((subcategory) => ({
        name: subcategory,
        weight: subcategoryWeights[subcategory],
      }));

      // Update the state with categories and subcategories
      setCategories(tempCategories);
      setSubcategories(tempSubcategories);
    }

    if (user) loadData();
  }, [selectedCategory, supabaseClient, user, userData?.is_donor]);

  const onClickSegment = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const onClickBar = (index: number) => {
    setActiveBarIndex(index);
  };

  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    index,
  }: ChartTypes.PieLabelRenderProps) => {
    if (
      typeof innerRadius === 'number' &&
      typeof outerRadius === 'number' &&
      typeof cx === 'number' &&
      typeof cy === 'number' &&
      percent
    ) {
      const radius = innerRadius + (outerRadius - innerRadius) * 1.2;
      const x = cx + radius * Math.cos(-midAngle * RADIAN);
      const y = cy + radius * Math.sin(-midAngle * RADIAN);

      const isClicked = activeIndex === index;

      if (isClicked) {
        const weight = selectedCategory ? subcategories[index]?.weight : categories[index]?.weight;
        const weightString = weight !== undefined ? weight.toString() : '';

        return (
          <text x={x} y={y} fill="black" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
            {`${weightString} kg`}
          </text>
        );
      } else {
        return null;
      }
    }
  };

  const toggleChartType = () => {
    setChartType(chartType === 'pie' ? 'bar' : 'pie');
  };

  const COLORS = schemeCategory10; // Use the color scheme for distinct and predefined colors

  const generatePDFReport = () => {
    const element = document.querySelector(`.${styles.wrapper}`);

    if (!element) return;
  };

  function calculateDateDifference(date1: string, date2: string) {
    const firstDate = new Date(date1);
    const secondDate = new Date(date2);

    if (!isNaN(firstDate.getTime()) && !isNaN(secondDate.getTime())) {
      const timeDifference = secondDate.getTime() - firstDate.getTime();
      const daysDifference = timeDifference / (1000 * 3600 * 24); // Convert milliseconds to days
      return daysDifference.toFixed(4);
    } else {
      return 'Invalid Date';
    }
  }

  async function generateCSVReportDonor() {
    if (!user?.id) return;
    const { data: donationsData, error: donationsError } = await supabaseClient
      .from('donations')
      .select(
        `
        created_at,
        category,
        subCategory,
        amount, 
        unit,
        collector_id,
        quantity,
        col_confirm,
        don_confirm,
        confirmDate,
        comments,
        title
      `
      )
      .eq('user_id', user.id)
      .eq('col_confirm', true)
      .eq('don_confirm', true);

    if (donationsError) {
      console.error('Error generating report:', donationsError);
      return;
    }

    const { data: userData, error: userError } = await supabaseClient.from('user_data').select('abn, id');

    if (userError) {
      console.error('Error generating report:', userError);
      return;
    }

    const { data: companyData, error: companyError } = await supabaseClient.from('company').select('abn, data');

    if (companyError) {
      console.error('Error generating report:', companyError);
      return;
    }

    if (donationsData && userData && companyData) {
      const userDataMap: { [key: string]: { abn: number | null } } = {};

      userData.forEach((user) => {
        userDataMap[user.id] = { abn: user.abn };
      });

      // Build a map of ABN to EntityName from companyData
      const abnToDataMap: {
        [key: string]: {
          EntityName?: string;
          BusinessName?: string;
          Acn?: string;
        };
      } = {};

      companyData.forEach((company) => {
        const abn = company.abn;
        const entityData = company.data;

        const entityInfo: {
          EntityName?: string;
          BusinessName?: string;
          Acn?: string;
        } = {};

        if (entityData && typeof entityData === 'object') {
          // Extract and store properties if they exist and handle null values
          entityInfo.EntityName =
            'EntityName' in entityData && typeof entityData.EntityName === 'string' ? entityData.EntityName : undefined;

          if ('BusinessName' in entityData) {
            if (Array.isArray(entityData.BusinessName) && entityData.BusinessName.length > 0) {
              if (typeof entityData.BusinessName[0] === 'string') {
                entityInfo.BusinessName = entityData.BusinessName[0];
              }
            } else if (typeof entityData.BusinessName === 'string') {
              entityInfo.BusinessName = entityData.BusinessName;
            }
          }

          entityInfo.Acn = 'Acn' in entityData && typeof entityData.Acn === 'string' ? entityData.Acn : undefined;
        }

        abnToDataMap[abn] = entityInfo;
      });

      // Convert amounts to kg and format data for CSV
      const csvContent =
        'Confirmation Date,Duration of Listing (days),Category,Subcategory,Donation Title,Amount (kg),Quantity,Additional Comments,Collector ABN,Collector Business Name,Collector ACN,Collector Entity Name,\n' +
        donationsData
          .map((row) => {
            const collectorAbn = userDataMap[row.collector_id!]?.abn;
            const abnNumber = collectorAbn as number;
            const { EntityName, BusinessName, Acn } = abnToDataMap[abnNumber] || {};

            const confirmationDate = row.confirmDate !== null ? formatDate(row.confirmDate) : 'N/A';
            const end = row.confirmDate !== null ? row.confirmDate : 'N/A';
            const start = row.created_at;

            const durationDays = row.confirmDate !== null ? calculateDateDifference(start, end) : 'N/A';

            return [
              `"${confirmationDate}"`,
              `"${durationDays}"`,
              `"${row.category ?? ''}"`,
              `"${row.subCategory ?? ''}"`,
              `"${row.title ?? ''}"`,
              convertToKilograms(row.amount, row.unit, row.quantity),
              `${row.quantity ?? 'N/A'}`,
              `${row.comments ?? 'N/A'}`,
              row.collector_id !== null ? `"${abnNumber || ''}"` : '',
              `"${BusinessName || 'N/A'}"`,
              `"${Acn || 'N/A'}"`,
              `"${EntityName || 'N/A'}"`,
            ].join(',');
          })
          .join('\n');

      // Create a Blob with the CSV content
      const blob = new Blob([csvContent], { type: 'text/plain;charset=utf-8' });

      // Save the Blob as a CSV file
      saveAs(blob, 'DonorReport.csv');
    }
  }

  async function generateCSVReportCollector() {
    if (!user?.id) return;
    const { data: donationsData, error: donationsError } = await supabaseClient
      .from('donations')
      .select(
        `
        created_at,
        category,
        subCategory,
        amount, 
        unit,
        user_id,
        quantity,
        col_confirm,
        don_confirm,
        confirmDate, 
        comments,
        title
      `
      )
      .eq('collector_id', user.id)
      .eq('col_confirm', true)
      .eq('don_confirm', true);

    if (donationsError) {
      console.error('Error generating report:', donationsError);
      return;
    }

    const { data: allUsersData, error: userError } = await supabaseClient.from('user_data').select('abn, id');

    if (userError) {
      console.error('Error generating report:', userError);
      return;
    }

    const { data: companyData, error: companyError } = await supabaseClient.from('company').select('abn, data');

    if (companyError) {
      console.error('Error generating report:', companyError);
      return;
    }

    if (donationsData && allUsersData && companyData) {
      const allUsersDataMap: { [key: string]: { abn: number | null } } = {};

      allUsersData.forEach((user) => {
        allUsersDataMap[user.id] = { abn: user.abn };
      });

      // Build a map of ABN to EntityName, BusinessName, and ACN from companyData
      const abnToInfoMap: {
        [key: string]: {
          EntityName?: string;
          BusinessName?: string;
          Acn?: string;
        };
      } = {};

      companyData.forEach((company) => {
        const abn = company.abn;
        const entityData = company.data;

        const entityInfo: {
          EntityName?: string;
          BusinessName?: string;
          Acn?: string;
        } = {};

        if (entityData && typeof entityData === 'object') {
          // Extract and store properties if they exist and handle null values
          entityInfo.EntityName =
            'EntityName' in entityData && typeof entityData.EntityName === 'string' ? entityData.EntityName : undefined;

          if ('BusinessName' in entityData) {
            if (Array.isArray(entityData.BusinessName) && entityData.BusinessName.length > 0) {
              if (typeof entityData.BusinessName[0] === 'string') {
                entityInfo.BusinessName = entityData.BusinessName[0];
              }
            } else if (typeof entityData.BusinessName === 'string') {
              entityInfo.BusinessName = entityData.BusinessName;
            }
          }

          entityInfo.Acn = 'Acn' in entityData && typeof entityData.Acn === 'string' ? entityData.Acn : undefined;
        }

        abnToInfoMap[abn] = entityInfo;
      });

      // Convert amounts to kg and format data for CSV
      const csvContent =
        'Confirmation Date,Duration of Listing (days),Category,Subcategory,Donation Title,Amount (kg),Quantity,Additional Comments,Donor ABN,Donor Business Name,Donor ACN,Donor Entity Name\n' +
        donationsData
          .map((row) => {
            const donorAbn = allUsersDataMap[row.user_id]?.abn;
            const abnNumber = donorAbn as number;
            const { EntityName, BusinessName, Acn } = abnToInfoMap[abnNumber] || {};

            const confirmationDate = row.confirmDate !== null ? formatDate(row.confirmDate) : 'N/A';
            const end = row.confirmDate !== null ? row.confirmDate : 'N/A';
            const start = row.created_at;

            const durationDays = row.confirmDate !== null ? calculateDateDifference(start, end) : 'N/A';

            return [
              `"${confirmationDate}"`,
              `"${durationDays}"`,
              `"${row.category ?? ''}"`,
              `"${row.subCategory ?? ''}"`,
              `"${row.title ?? ''}"`,
              convertToKilograms(row.amount, row.unit, row.quantity),
              `${row.quantity ?? 'N/A'}`,
              `${row.comments ?? 'N/A'}`,
              `"${abnNumber || ''}"`,
              `"${BusinessName || 'N/A'}"`,
              `"${Acn || 'N/A'}"`,
              `"${EntityName || 'N/A'}"`,
            ].join(',');
          })
          .join('\n');

      const blob = new Blob([csvContent], { type: 'text/plain;charset=utf-8' });

      saveAs(blob, 'CollectorReport.csv');
    }
  }

  return (
    <PageWrapper backBtn>
      <div className={styles.outerWrapper}>
        <div className={styles.generateSection}>
          <h3>Generate CSV Reports</h3>
          <i>Note these only include completed {!!userData?.is_donor ? 'donations' : 'collections'}</i>
          {!!userData?.is_donor && (
            <button className={styles.generateButton} onClick={generateCSVReportDonor}>
              Donations
            </button>
          )}
          {!userData?.is_donor && (
            <button className={styles.generateButton} onClick={generateCSVReportCollector}>
              Collections
            </button>
          )}
        </div>

        <div className={styles.wrapper}>
          {!!categories.length ? (
            <>
              {!!userData?.is_donor && <h3>Donated By Category</h3>}
              {!userData?.is_donor && <h3>Collected By Category</h3>}

              <div className={styles.showAsContainer}>
                <div className={styles.showAsLabel}>Show as:</div>
              </div>
              <select value={selectedCategory || ''} onChange={(e) => setSelectedCategory(e.target.value || null)}>
                <option value="">All Categories</option>
                {categories.map((entry) => (
                  <option key={entry.name} value={entry.name}>
                    {entry.name}
                  </option>
                ))}
              </select>
              <div className={styles.showChartTypeContainer}>
                <button className={styles.chartTypeButton} onClick={toggleChartType}>
                  Show {chartType === 'pie' ? 'Bar Chart' : 'Pie Chart'}
                </button>
              </div>
              {chartType === 'pie' ? (
                <PieChart className={styles.chart} width={300} height={300}>
                  <Pie
                    data={selectedCategory ? subcategories : categories}
                    isAnimationActive={true}
                    innerRadius={0}
                    outerRadius={80}
                    labelLine={false}
                    label={renderCustomizedLabel}
                    onClick={(data, index) => onClickSegment(index)}
                    fill="#8884d8"
                    paddingAngle={0}
                    dataKey="weight">
                    {selectedCategory
                      ? subcategories.map((entry, index) => (
                          <Cell key={`cell-${entry?.name}`} fill={COLORS[index % COLORS.length]} />
                        ))
                      : categories.map((entry, index) => (
                          <Cell key={`cell-${entry?.name}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                  </Pie>
                  <Legend align="center" layout="horizontal" />
                </PieChart>
              ) : (
                <BarChart
                  className={styles.chart}
                  width={300}
                  height={300}
                  data={selectedCategory ? subcategories : categories}
                  margin={{ top: 40, right: 40, left: 0, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" interval={0} />
                  <YAxis
                    label={{
                      value: 'Weight (kg)',
                      angle: -90,
                      position: 'insideLeft',
                      offset: 10,
                    }}
                  />
                  <Tooltip formatter={(value) => `${Number(value).toFixed(2)} kg`} />
                  <Bar dataKey="weight" isAnimationActive={true}>
                    {selectedCategory
                      ? subcategories.map((entry, index) => (
                          <Cell
                            key={`cell-${entry?.name}`}
                            fill={COLORS[index % COLORS.length]}
                            onClick={() => onClickBar(index)}
                            // Apply active class to the clicked bar
                            className={activeBarIndex === index ? styles.activeBar : ''}
                          />
                        ))
                      : categories.map((entry, index) => (
                          <Cell
                            key={`cell-${entry?.name}`}
                            fill={COLORS[index % COLORS.length]}
                            onClick={() => onClickBar(index)}
                            // Apply active class to the clicked bar
                            className={activeBarIndex === index ? styles.activeBar : ''}
                          />
                        ))}
                  </Bar>
                </BarChart>
              )}
            </>
          ) : (
            <div className={styles.noData}>
              {!!userData?.is_donor && (
                <p>
                  You haven&apos;t had any donations collected.
                  <br />
                  When you do, they will appear in your reporting suite!
                </p>
              )}
              {!userData?.is_donor && (
                <p>
                  You haven&apos;t made any collections.
                  <br />
                  Collect some to see your reporting suite!
                </p>
              )}
              <Link href="/donations">
                <button className={styles.toggleButton}>Donations Page</button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </PageWrapper>
  );
};

export default Reports;
