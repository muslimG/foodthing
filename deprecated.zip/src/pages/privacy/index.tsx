import Link from 'next/link';
import PageWrapper from '@/components/layout/PageWrapper';
import React from 'react';
import styles from './index.module.scss';
import { useRouter } from 'next/router';
import { useUser } from '@supabase/auth-helpers-react';

const Privacy = () => {
  const router = useRouter();
  const user = useUser();

  return (
    <PageWrapper showNavbar={!!user}>
      <div className={styles.wrapper}>
        <h1>Privacy Policy</h1>
        <br></br>
        <div className={styles.linkContainer}>
          <p>Edith Cowan University manages personal information in accordance with its Privacy Policy available at</p>
          <Link rel="non-referrer" href="https://www.ecu.edu.au/supplemental/privacy">
            https://www.ecu.edu.au/supplemental/privacy
          </Link>{' '}
          .
          <p>
            Please note, some personal information provided via this app may be publicly displayed or made available to
            other users. If you have any concerns, please contact our team at{' '}
            <a href="mailto:refood@ecu.edu.au" className={styles.emailAddress}>
              refood@ecu.edu.au
            </a>
            .
          </p>
          <button className={styles.close} onClick={() => router.back()}>
            Return
          </button>
        </div>
      </div>
    </PageWrapper>
  );
};

export default Privacy;
