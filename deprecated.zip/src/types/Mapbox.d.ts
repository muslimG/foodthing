namespace Mapbox {
  // You can edit the Marker interface but don't edit the other ones
  interface Marker {
    lng?: number;
    lat?: number;
    title?: string | null;
    id?: number | null;
    location?: string | null;
    imagePath?: string | null;
    subCategory?: string | null;
  }

  interface GeocodeResult {
    type: string;
    query: string[];
    features: GeocodeFeature[];
    attribution: string;
  }

  interface GeocodeFeature {
    id: string;
    type: string;
    place_type: string[];
    relevance: number;
    properties: {
      accuracy: string;
      mapbox_id: string;
    };
    text: string;
    place_name: string;
    center: [number, number];
    geometry: {
      type: string;
      coordinates: [number, number];
    };
    context: GeocodeContext[];
  }

  interface GeocodeContext {
    id: string;
    mapbox_id: string;
    wikidata?: string;
    text: string;
    short_code?: string;
  }
}
