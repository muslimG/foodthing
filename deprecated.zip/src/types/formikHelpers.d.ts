namespace FormikHelper {
  interface DonationValues {
    quantity: any;
    imagePath: string;
    title: string;
    description: string;
    amount: number;
    unit: string;
    endDate: string;
    location: string;
    locationData: Json | null;
    category: string;
    subCategory: string;
  }

  interface LoginValues {
    email: string;
    password: string;
  }

  interface ForgotPassword {
    email: string;
  }

  interface ResetPassword {
    password: string;
    confirmPassword: string;
  }

  interface SignUpForm {
    userType: 'donor' | 'collector';
    email: string;
    phone: string;
    password: string;
    confirmPassword: string;
    email: string;
    firstName: string;
    lastName: string;
    businessName: string;
    address: string;
    addressData: Mapbox.GeocodeFeature | null;
    abn: string;
    password: string;
    confirmPassword: string;
    termsAccepted: boolean;
  }

  interface Search {
    search: string;
  }

  interface UserUpdateForm extends Omit<Omit<Tables.UserData, 'created_at'>, 'id'> {}
}
