type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

interface Database {
  public: {
    Tables: {
      chat_messages: {
        Row: {
          chat_date: string | null;
          chat_text: string | null;
          donation_id: number | null;
          id: number;
          is_read: boolean | null;
          sender_id: string | null;
        };
        Insert: {
          chat_date?: string | null;
          chat_text?: string | null;
          donation_id?: number | null;
          id?: number;
          is_read?: boolean | null;
          sender_id?: string | null;
        };
        Update: {
          chat_date?: string | null;
          chat_text?: string | null;
          donation_id?: number | null;
          id?: number;
          is_read?: boolean | null;
          sender_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: 'chat_messages_donation_id_fkey';
            columns: ['donation_id'];
            referencedRelation: 'donations';
            referencedColumns: ['id'];
          },
          {
            foreignKeyName: 'chat_messages_sender_id_fkey';
            columns: ['sender_id'];
            referencedRelation: 'user_data';
            referencedColumns: ['id'];
          },
        ];
      };
      company: {
        Row: {
          abn: number;
          created_at: string;
          data: Json;
        };
        Insert: {
          abn?: number;
          created_at?: string;
          data: Json;
        };
        Update: {
          abn?: number;
          created_at?: string;
          data?: Json;
        };
        Relationships: [];
      };
      donations: {
        Row: {
          amount: number | null;
          category: string | null;
          col_confirm: boolean | null;
          collect_date: string | null;
          collector_id: string | null;
          comments: string | null;
          confirmDate: string | null;
          created_at: string;
          description: string | null;
          don_confirm: boolean | null;
          end_date: string | null;
          id: number;
          imagePath: string | null;
          location: string | null;
          location_data: Json | null;
          quantity: number | null;
          subCategory: string | null;
          title: string | null;
          unit: string | null;
          user_id: string;
        };
        Insert: {
          amount?: number | null;
          category?: string | null;
          col_confirm?: boolean | null;
          collect_date?: string | null;
          collector_id?: string | null;
          comments?: string | null;
          confirmDate?: string | null;
          created_at?: string;
          description?: string | null;
          don_confirm?: boolean | null;
          end_date?: string | null;
          id?: number;
          imagePath?: string | null;
          location?: string | null;
          location_data?: Json | null;
          quantity?: number | null;
          subCategory?: string | null;
          title?: string | null;
          unit?: string | null;
          user_id: string;
        };
        Update: {
          amount?: number | null;
          category?: string | null;
          col_confirm?: boolean | null;
          collect_date?: string | null;
          collector_id?: string | null;
          comments?: string | null;
          confirmDate?: string | null;
          created_at?: string;
          description?: string | null;
          don_confirm?: boolean | null;
          end_date?: string | null;
          id?: number;
          imagePath?: string | null;
          location?: string | null;
          location_data?: Json | null;
          quantity?: number | null;
          subCategory?: string | null;
          title?: string | null;
          unit?: string | null;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: 'donations_collector_id_fkey';
            columns: ['collector_id'];
            referencedRelation: 'user_data';
            referencedColumns: ['id'];
          },
          {
            foreignKeyName: 'donations_user_id_fkey';
            columns: ['user_id'];
            referencedRelation: 'user_data';
            referencedColumns: ['id'];
          },
        ];
      };
      notifications: {
        Row: {
          created_at: string;
          donation_id: number | null;
          id: number;
          seen: boolean;
          title: string | null;
          user_id: string | null;
        };
        Insert: {
          created_at?: string;
          donation_id?: number | null;
          id?: number;
          seen?: boolean;
          title?: string | null;
          user_id?: string | null;
        };
        Update: {
          created_at?: string;
          donation_id?: number | null;
          id?: number;
          seen?: boolean;
          title?: string | null;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: 'notifications_donation_id_fkey';
            columns: ['donation_id'];
            referencedRelation: 'donations';
            referencedColumns: ['id'];
          },
          {
            foreignKeyName: 'notifications_user_id_fkey';
            columns: ['user_id'];
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
      push_subscriptions: {
        Row: {
          created_at: string;
          id: number;
          subscription: Json | null;
          user_id: string | null;
        };
        Insert: {
          created_at?: string;
          id?: number;
          subscription?: Json | null;
          user_id?: string | null;
        };
        Update: {
          created_at?: string;
          id?: number;
          subscription?: Json | null;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: 'push_subscriptions_user_id_fkey';
            columns: ['user_id'];
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
      user_data: {
        Row: {
          abn: number | null;
          address: string | null;
          address_data: Json | null;
          avatar_url: string | null;
          created_at: string;
          first_name: string | null;
          id: string;
          is_donor: boolean;
          last_name: string | null;
          phone: string | null;
        };
        Insert: {
          abn?: number | null;
          address?: string | null;
          address_data?: Json | null;
          avatar_url?: string | null;
          created_at?: string;
          first_name?: string | null;
          id: string;
          is_donor?: boolean;
          last_name?: string | null;
          phone?: string | null;
        };
        Update: {
          abn?: number | null;
          address?: string | null;
          address_data?: Json | null;
          avatar_url?: string | null;
          created_at?: string;
          first_name?: string | null;
          id?: string;
          is_donor?: boolean;
          last_name?: string | null;
          phone?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: 'user_data_abn_fkey';
            columns: ['abn'];
            referencedRelation: 'company';
            referencedColumns: ['abn'];
          },
          {
            foreignKeyName: 'user_data_id_fkey';
            columns: ['id'];
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
}
