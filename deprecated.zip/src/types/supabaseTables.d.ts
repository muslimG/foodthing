namespace Tables {
  interface ChatMessages {
    chat_date: string | null;
    chat_text: string | null;
    donation_id: number | null;
    id: number;
    is_read: boolean | null;
    sender_id: string | null;
  }

  interface Company {
    abn: number;
    created_at: string;
    data: Json;
  }

  interface Donations {
    amount: number | null;
    category: string | null;
    col_confirm: boolean | null;
    collect_date: string | null;
    collector_id: string | null;
    comments: string | null;
    confirmDate: string | null;
    created_at: string;
    description: string | null;
    don_confirm: boolean | null;
    end_date: string | null;
    id: number;
    imagePath: string | null;
    location: string | null;
    location_data: Json | null;
    quantity: number | null;
    subCategory: string | null;
    title: string | null;
    unit: string | null;
    user_id: string;
  }

  interface Notifications {
    created_at: string;
    donation_id: number | null;
    id: number;
    seen: boolean;
    title: string | null;
    user_id: string | null;
  }

  interface PushSubscriptions {
    created_at: string;
    id: number;
    subscription: Json | null;
    user_id: string | null;
  }

  interface UserData {
    abn: number | null;
    address: string | null;
    address_data: Json | null;
    avatar_url: string | null;
    created_at: string;
    first_name: string | null;
    id: string;
    is_donor: boolean;
    last_name: string | null;
    phone: string | null;
  }
}
