const ts = require('typescript');
const fs = require('fs');

function parseNodes(nodes, result = []) {
  for (const node of nodes) {
    if (ts.isInterfaceDeclaration(node) && node.name.escapedText === 'Database') {
      for (const member of node.members) {
        if (ts.isPropertySignature(member) && member.name.escapedText === 'public') {
          const tables = member.type.members.find((m) => m.name.escapedText === 'Tables');

          for (const table of tables.type.members) {
            const tableName = table.name.escapedText;
            const rowType = table.type.members.find((m) => m.name.escapedText === 'Row');

            if (rowType && rowType.type && rowType.type.members) {
              const properties = rowType.type.members
                .map((property) => {
                  if (property.name && property.type) {
                    const name = property.name.escapedText;
                    const type = property.type.getText();
                    return `${name}: ${type};`;
                  }
                })
                .filter(Boolean)
                .join('\n  ');

              const camelCaseName = tableName.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
              const UpperCamelCaseName = camelCaseName.charAt(0).toUpperCase() + camelCaseName.slice(1);

              result.push(`interface ${UpperCamelCaseName} {\n  ${properties}\n}`);
            }
          }
        }
      }
    }
    parseNodes(node.getChildren(), result);
  }
  return result;
}

const fileContent = fs.readFileSync('src/types/supabase.d.ts').toString();
const sourceFile = ts.createSourceFile('src/types/supabase.d.ts', fileContent, ts.ScriptTarget.Latest, true);

const interfaces = parseNodes(sourceFile.getChildren());

const namespaceWrapped = `
namespace Tables {
${interfaces.join('\n\n')}
}
`;

fs.writeFileSync('src/types/supabaseTables.d.ts', namespaceWrapped, 'utf-8');
console.log('File has been created');
