const fs = require('fs');

const typeFile = fs.readFileSync('src/types/supabase.d.ts', 'utf-8');

const newFile = typeFile.replace(/export /gi, '');

fs.writeFileSync('src/types/supabase.d.ts', newFile);
