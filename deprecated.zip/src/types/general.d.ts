type AbnResponse = AbnResponseSucess | AbnResponseFailure;

interface AbnData {
  Abn: string;
  AbnStatus: string;
  AbnStatusEffectiveFrom: string;
  Acn: string;
  AddressDate: string;
  AddressPostcode: string;
  AddressState: string;
  BusinessName: string[];
  EntityName: string;
  EntityTypeCode: string;
  EntityTypeName: string;
  Gst: string | null;
  Message: string;
}

interface AbnResponseSucess {
  success: boolean;
  abnData: AbnData;
}

interface InsertPayload<TableRecord> {
  type: 'INSERT';
  table: string;
  schema: string;
  record: TableRecord;
  old_record: null;
}

interface UpdatePayload<TableRecord> {
  type: 'UPDATE';
  table: string;
  schema: string;
  record: TableRecord;
  old_record: TableRecord;
}

interface DeletePayload<TableRecord> {
  type: 'DELETE';
  table: string;
  schema: string;
  record: null;
  old_record: TableRecord;
}

/**
 * Make all properties in T optional
 */
type Partial<T> = {
  [A in keyof T]?: T[A];
};
