namespace Field {
  interface Option {
    value: string;
    label: string;
    disabled?: boolean;
  }

  type Options = Option[];
}
