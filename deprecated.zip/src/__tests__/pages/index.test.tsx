import Index from '@/pages/index';
import React from 'react';
import { render } from '@testing-library/react';

jest.mock('@supabase/auth-helpers-react', () => {
  return {
    useSupabaseClient: jest.fn(() => {}),
    useUser: () => true,
  };
});

jest.mock('@supabase/auth-ui-react', () => {
  return {
    Auth: () => null,
  };
});

const component = <Index />;

describe('<Index />', () => {
  it('renders', () => {
    const wrapper = render(component);

    expect(wrapper.getByText('ReFood')).toBeDefined();
    expect(wrapper.asFragment()).toMatchSnapshot();
  });
});
