import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs';

export async function middleware(req: NextRequest) {
  // We need to create a response and hand it to the supabase client to be able to modify the response headers.
  const res = NextResponse.next();

  // Create authenticated Supabase Client.
  const supabase = createMiddlewareClient({ req, res });
  // Check if we have a session
  const {
    data: { session },
  } = await supabase.auth.getSession();
  const requestedPath = req?.nextUrl?.pathname;
  const nonAuthAllowedPaths = ['/sign-up', '/forgot-password'];

  // Check auth condition
  if (!!session?.user?.email) {
    // If logged in take them to home rather than login page
    if (['/', ...nonAuthAllowedPaths]?.includes(requestedPath)) {
      const redirectUrl = req.nextUrl.clone();
      redirectUrl.pathname = '/home';
      redirectUrl.searchParams.set(`redirectedFrom`, req.nextUrl.pathname);
      return NextResponse.redirect(redirectUrl);
    }

    // Authentication successful, forward request to protected route.
    return res;
  }

  const allowedStartWithPath = nonAuthAllowedPaths?.find((value) => requestedPath?.startsWith(value));
  const allowedExactPath = ['/', '/_offline', '/privacy']?.includes(requestedPath);

  // allow homepage for non logged in users
  if (allowedExactPath || !!allowedStartWithPath) {
    return res;
  }

  // This log is only visible serverside (via terminal in dev)
  console.log(`not authenticated for ${requestedPath}`);

  // Auth condition not met, redirect to login page.
  const redirectUrl = req.nextUrl.clone();
  redirectUrl.pathname = '/';
  redirectUrl.searchParams.set(`redirectedFrom`, req.nextUrl.pathname);
  return NextResponse.redirect(redirectUrl);
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico|manifest.json|icons|sw|workbox|worker|assets|logo|robots).*)',
  ],
};
