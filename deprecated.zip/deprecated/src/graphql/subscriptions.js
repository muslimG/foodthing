/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateFavouritesTable = /* GraphQL */ `
  subscription OnCreateFavouritesTable {
    onCreateFavouritesTable {
      id
      userID
      donationID
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateFavouritesTable = /* GraphQL */ `
  subscription OnUpdateFavouritesTable {
    onUpdateFavouritesTable {
      id
      userID
      donationID
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteFavouritesTable = /* GraphQL */ `
  subscription OnDeleteFavouritesTable {
    onDeleteFavouritesTable {
      id
      userID
      donationID
      createdAt
      updatedAt
    }
  }
`;
export const onCreateMessage = /* GraphQL */ `
  subscription OnCreateMessage {
    onCreateMessage {
      id
      channelID
      author
      body
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateMessage = /* GraphQL */ `
  subscription OnUpdateMessage {
    onUpdateMessage {
      id
      channelID
      author
      body
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteMessage = /* GraphQL */ `
  subscription OnDeleteMessage {
    onDeleteMessage {
      id
      channelID
      author
      body
      createdAt
      updatedAt
    }
  }
`;
export const onCreateFOODITEM = /* GraphQL */ `
  subscription OnCreateFOODITEM {
    onCreateFOODITEM {
      id
      title
      pickup_date
      category
      transport_reqs
      picture
      donorID
      nfpID
      pickup_location
      quantity
      description
      isCompleted
      completionDate
      start_time
      end_time
      donorName
      donorPhone
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateFOODITEM = /* GraphQL */ `
  subscription OnUpdateFOODITEM {
    onUpdateFOODITEM {
      id
      title
      pickup_date
      category
      transport_reqs
      picture
      donorID
      nfpID
      pickup_location
      quantity
      description
      isCompleted
      completionDate
      start_time
      end_time
      donorName
      donorPhone
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteFOODITEM = /* GraphQL */ `
  subscription OnDeleteFOODITEM {
    onDeleteFOODITEM {
      id
      title
      pickup_date
      category
      transport_reqs
      picture
      donorID
      nfpID
      pickup_location
      quantity
      description
      isCompleted
      completionDate
      start_time
      end_time
      donorName
      donorPhone
      createdAt
      updatedAt
    }
  }
`;
