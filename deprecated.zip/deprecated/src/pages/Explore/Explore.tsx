import React from 'react';
import SearchPage from './SearchPage'; // import searchbar

function Explore() {
  return (
    <div className="searchPage">
      <SearchPage placeholder="enter here..." />
    </div>
  );
}

export default Explore;
