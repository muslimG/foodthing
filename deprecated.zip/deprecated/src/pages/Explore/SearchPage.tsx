import React, { useEffect, useState } from 'react';
import {
  Amplify,
  API,
  Auth,
  AWSCloudWatchProvider,
  graphqlOperation,
} from 'aws-amplify';
import styles from './SearchPage.module.scss';
import * as queries from '@/graphql/queries';
import Explore from './Explore';
import Image from '@/components/Image';

interface Props {
  placeholder: string;
  data?: any; // TODO - figure out type
}

function SearchPage({ placeholder, data }: Props) {
  // Array to store FoodItems
  const [foodItems, setFoodItems] = useState([]);

  function clearText() {
    let input1 = document.getElementById('input1');
    let input2 = document.getElementById('input2');

    input1?.setAttribute('value', '');
    input2?.setAttribute('value', '');
  }

  // Fetches donations from database
  const fetchDonations = async () => {
    try {
      // TODO fix typing after db setup
      const allDonations = await API.graphql({ query: queries.listFOODITEMS });
      const itemList = (allDonations as any)?.data?.listFOODITEMS?.items;
      setFoodItems(itemList);
    } catch (error) {
      console.log('error in fetching FoodItems', error);
    }
  };

  useEffect(() => {
    fetchDonations();
  }, []);

  return (
    <div className={styles.wrapper}>
      <div className={styles.search}>
        <div className={styles.searchHeader}>What Food</div>
        <div className={styles.inputs}>
          <input
            id="input1"
            type="text"
            placeholder={placeholder}
            name="input1"
          />
        </div>
        <div className={styles.dataResult}></div>
      </div>

      <div className={styles.search}>
        <div className={styles.searchHeader}>Where</div>
        <input
          id="input2"
          type="text"
          name="input2"
          placeholder="enter here..."
        />
      </div>

      <div className={styles.buttonsContainer}>
        <button onClick={clearText}>Clear all</button>

        <a href="/listpage">
          <button className={styles.searchBtn}>
            <Image src="assets/icons/PNG/search.png" alt="search icon" />
            Search
          </button>
        </a>
      </div>

      <div className="foodItemList hidden">
        {/* // TODO change typing of foodItem */}
        {foodItems.map((foodItem: any, idx) => {
          return (
            <div
              className={styles.foodItemCard}
              key={`${foodItem.title}-${idx}`}
            >
              <div>{foodItem.title}</div>
              <div>{foodItem.quantity}</div>
              <div>{foodItem.description}</div>
              <div>{foodItem.category}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default SearchPage;
