import { Amplify, Auth } from 'aws-amplify';
import React, { useEffect, useState } from 'react';

import { type } from '@testing-library/user-event/dist/type';

function Explore({}) {
  return <div>Explore Page</div>;
}

export default Explore;
