import React from 'react';

function Home(props) {
  return (
    <div>
      <a href="/donation">Donate</a>
    </div>
  );
}

export default Home;
