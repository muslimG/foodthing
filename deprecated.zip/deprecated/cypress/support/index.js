// // index.js
// const customCommands = require('./commands.js')

// module.exports = {
//   commands: customCommands
// }