{ 
  "username": "refood3200@gmail.com", 
  "password": "Cits3200@", 
  "userPoolId": "us-west-1_im2Y8lF6V", 
  "clientId": "1gblfrb4jcbu3gpoberrj37rn6" 
}